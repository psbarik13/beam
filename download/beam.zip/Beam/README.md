# Beam

Send a file from one device to another with a stream of QR codes. No Wi-Fi, cable, account or internet. Everything is inside `beam.html` (about 1.4 MB), including the QR reader.

**Web link:** https://psbarik13.github.io/beam/ (downloads: https://psbarik13.github.io/beam/download/)

## Open it

| Device | Send | Receive (needs the camera) |
|---|---|---|
| PC or Mac | Double-click `beam.html` | Double-click `start-beam.bat` (Windows) or `start-beam.command` (Mac). It opens Beam at `http://localhost`, where the browser asks for the camera normally. |
| Phone | Open https://psbarik13.github.io/beam/ | Open https://psbarik13.github.io/beam/ |

Browsers often block the camera on pages opened straight from a file, without asking. That is why receiving on a computer goes through `start-beam`, which needs Node.js. If something blocks the camera, Beam says what blocked it and how to fix it. It also tells you if the device has no camera.

## Use it

1. **Sender:** choose a file, tap **Send**. Turn the screen brightness up. For a photo or video, **Reduce size** can make it much smaller first (optional).
2. **Receiver:** tap **Receive**, allow the camera, point it at the sender's screen.
3. When it finishes, the file opens. Zoom with pinch, the mouse wheel or the + and − buttons. Tap **Save** (or **Share** on phones).

The receiver shows how many codes a second it reads and what share it catches. If it says the sender is too fast, lower **Speed**. If it says it keeps up, raise it.

## Reduce size (optional)

Shown when you pick a photo or a video. Leave it on **Original** to send the exact file.

- **Photos: Large, Medium, Small** resize to 2560, 1600 or 1024 pixels on the long side and recompress. A 3 MB phone photo usually becomes 0.1–0.5 MB.
- **Videos: 720p, 480p, 360p** re-encode in the browser with sound. It takes as long as the video plays, so keep the screen open. A 360p copy is often a tenth of the size or less.

If the result isn't smaller, Beam sends the original.

## Sender controls

- **Speed**: frames a second, 1 to 60. 8 to 15 suits most cameras; 30 or more needs a fast phone camera.
- **Density**: data per code, 180 B to 2.7 KB (QR version 40).
- **Error correction**: L, M, Q or H. L packs the most. Raise it if glare or blur stops codes reading.
- **Codes on screen**: 1, 2, 4 or 6 codes at once, filling wide screens. 2 side by side on a laptop roughly doubles what the screen carries. Hold the phone sideways so all codes are in view.
- **Hide controls** and **Full screen** give the codes the whole display.

Change any of these mid-transfer; the receiver keeps its progress.

## Receiver options

- **Camera: fastest fps / 30 fps**. By default Beam asks the camera for its highest frame rate (often 60 fps on phones).
- **Camera: HD / 4K**. 4K resolves denser codes and more codes at once, but decoding each frame takes longer.
- **Reader**: automatic, built-in (fast on Android Chrome) or ZXing (works everywhere, including iPhone).

## How fast

| Setup | Typical speed | 1 MB takes |
|---|---|---|
| Phone reading a laptop, 1 code | 10–25 KB/s | 40 s – 2 min |
| Phone reading a laptop, 2–4 codes | 20–40 KB/s | 25 s – 1 min |
| Laptop webcam reading a phone | 5–10 KB/s | 2 – 3.5 min |

Text and documents are compressed first, so they often go several times faster. Videos are usually too large unless you use **Reduce size**.

## How it works

The file is cut into 180-byte chunks. Each QR code carries an 18-byte header and several pieces, each tagged with 4 bytes:

- **Chunks**: the file's own chunks with their number, sent in order. The receiver drops each one straight into place.
- **Repair pieces**: random mixes of chunks (a fountain code). They fill whatever chunks the camera missed, so you never wait for the loop to come around again.

The first pass sends two chunks for every repair piece; after every chunk has gone out once, only repair pieces follow. The receiver needs about as many pieces as the file has chunks, plus under 1 percent, in any order. Stitching and repair run in a background worker, so the camera view and controls never freeze.

Both sides work in parallel. The sender draws upcoming codes in background workers, so it can show up to 60 a second. The receiver puts each camera frame in a small buffer, and up to 4 reader workers (the phone's cores minus two, leaving room for the page and the stitcher) decode frames at the same time. When the readers fall behind, the oldest frames are dropped so the newest are always read. The receiver screen shows the camera's frame rate and how many frames a second are checked.

Data travels as Base45 in QR alphanumeric mode, which every QR reader returns exactly. The file name, type and a CRC-32 checksum travel with the data; the receiver checks the checksum before showing the file.
