# Beam

Send a file from one device to another through the screen and the camera: a full-screen colour grid (or QR codes) on one device, the camera on the other. No Wi-Fi, cable, account or internet. Files are compressed first (Word, Excel and PowerPoint files often to a third). You can also export the codes to print them or show them on any screen, protect a file with a password, and import codes from files or photos. Everything is inside `beam.html` (about 2.5 MB).

**Web link:** https://psbarik13.github.io/beam/ (downloads: https://psbarik13.github.io/beam/download/)

## Open it

| Device | Send | Receive (needs the camera) |
|---|---|---|
| PC or Mac | Double-click `beam.html` | Double-click `start-beam.bat` (Windows) or `start-beam.command` (Mac). It opens Beam at `http://localhost`, where the browser asks for the camera normally. |
| Phone | Open https://psbarik13.github.io/beam/ | Open https://psbarik13.github.io/beam/ |

Browsers often block the camera on pages opened straight from a file, without asking. That is why receiving on a computer goes through `start-beam`, which needs Node.js. If something blocks the camera, Beam says what blocked it and how to fix it. It also tells you if the device has no camera.

## Use it

1. **Sender:** choose a file, tap **Send**. Turn the screen brightness up. For a photo or video, **Reduce size** can make it much smaller first (optional). Type a **Password** to protect the file (optional).
2. **Receiver:** tap **Receive**, allow the camera, and point it at the sender's screen so the whole grid fills the view, with all four corner squares inside it. Hold the phone the same way round as the sender's screen (sideways for a laptop).
3. When it finishes, the file opens (after the password, if the sender set one). Zoom with pinch, the mouse wheel or the + and − buttons. Tap **Save** (or **Share** on phones).

The receiver works out by itself whether the sender shows the colour grid or QR codes.

- **Live outline:** it draws an outline on the camera view around what it sees: green when the grid reads well, amber when some of it fails, red when most fails. Each block gets a dot (green read, red failed), so you can see where glare or blur is.
- **Settings advice:** during a transfer it measures what its camera can do and shows **Faster sender settings** (density, colours, error correction, speed) with the speed to expect.
- **Sweep reading:** the camera doesn't have to see the whole code. Hold it close to part of a screen or a printed page and move it slowly, row by row; every block it passes over counts, and the bar shows what's left. Green dots mark blocks read, red ones blocks that failed (hold there a moment). Works with 4 and 8 colours; 2-colour codes must be seen whole.
- **Small squares (a dense page, or a code far away):** a phone's video is only about 2 megapixels, so the receiver helps by itself, but only when it has found a whole code, measured its squares as too small, and read nothing new for 2 seconds. If zooming in on the whole code is enough, it does that (only as far as keeps the whole code in view). If not, it starts a **zoom scan**: a phone camera can only zoom into the middle of its view, so Beam draws a ring on the part of the code to read next, with an arrow and "tilt the phone left / right / up / down". Bring the ring to the cross in the middle (same distance), and Beam zooms in as far as adds real detail (about 6 camera pixels per square; on iPhone at most 2×), reads that part, zooms back out and rings the next part. Where Beam can't control the zoom (often on iPhone), the same scan asks you to move the phone closer to each part instead, then back. On Chrome and Edge for Android it takes full-resolution photos first (12 MP or more), which read a whole page without moving; the scan is for pages too dense even for that.
- **Auto zoom switch:** the **Auto zoom: on / off** button on the camera view. Off: Beam never changes the zoom (for live screens and moving QR codes).
- **Photo:** tap **Photo** to take a full-resolution picture at any time (on iPhone it opens the camera app). Each photo shows as a small map: green dots are parts read, red dots parts that didn't read, with a line saying what to do (for example, take a closer photo of the red part). Photos and live video add to the same transfer.

## Colour grid (the default, and the fast mode)

The whole screen becomes one code: a grid of small coloured squares with a black-and-white corner square at each corner. Each frame carries 5 to 30 KB, where one QR code carries at most 2.7 KB.

- **Speed**: frames a second. 15 suits most phones; 30 if the receiving camera runs at 60 fps (the receiver tells you).
- **Density**: about how many squares along the long side (128 to 1024). The grid then fills the whole screen, so the actual count is a little higher. 288 suits a 1080p phone camera that fills its view with the grid. Go higher for 4K cameras or when the receiver says it reads cleanly; lower if it says the squares are too small.
- **Colours**: 2 (black and white, the most robust), 4 (the default) or 8 (the most data, needs a sharp camera close up). Why not 16: in the camera simulation 16 colours only read with squares 9 px wide or bigger, and then carry less per frame (6.7 to 11 KB) than 8 colours with smaller squares (13 to 18 KB). More colours sit closer together, so the camera confuses them sooner than smaller squares blur.
- **Error correction**: L, M or H. Each block fixes up to 12, 18 or 27 wrong bytes of 200. Raise it if the receiver loses many blocks.
- **Hide settings** folds the panel down to one line (name, speed, Stop), and the grid grows to fill the space. **Hide everything** and **Full screen** give it the whole display.

## QR mode

Standard QR codes, for when a plain QR reader must be able to check them, or the grid doesn't read.

- **Speed**: 1 to 60 frames a second. 8 to 15 suits most cameras.
- **Density**: data per code, 180 B to 2.7 KB (QR version 40).
- **Error correction**: L, M, Q or H.
- **Codes on screen**: 1, 2, 4 or 6 codes at once, filling wide screens.

Change any setting mid-transfer, in either mode; the receiver keeps its progress.

## Speed test

Finds the fastest settings for a particular pair of devices. It runs until you stop it.

1. **Sender:** on the home screen, under **Speed test**, tap **Test pattern** (you choose the settings) or **Auto sweep**. Auto sweep loops through settings for ever, about two minutes per round: densities × 2, 4 and 8 colours at 10 frames a second, then speeds from 6 to 60 frames a second, then error correction L and H.
2. **Receiver:** tap **Receive** as usual. It sees the test frames and shows:
   - the live speed in KB/s and the share of blocks lost;
   - the sender's current settings;
   - a table of every setting measured, fastest first;
   - **Best measured** and, after an auto sweep round, **Predicted best**: the speed of each density and colour count combined with how fast this camera keeps up.

Change settings on either device whenever you like; results are kept per receiver camera setting. **Copy results** puts the table on the clipboard as CSV. The link only runs from sender to receiver, so set the recommended settings on the sender yourself.

## Compression

Beam compresses every file before sending it, and always losslessly. It tries three compressors and keeps the smallest:

- **zstd**: fast, and finds repeats far apart (big spreadsheets).
- **PPMd**: best on text. About a fifth smaller than zstd on plain text and on the XML inside documents.
- **LZMA**: best on some large structured files (big Excel workbooks, many PDFs).

**JPEG photos** are repacked with Brunsli: usually 15–35% smaller, and the receiver gets the very same bytes. This works for a photo on its own and for JPEG pictures inside PDFs, Word, PowerPoint and other documents. Other pictures (PNG, HEIC, WebP), videos, music and archives are already compressed, so they go as they are. (For much smaller photos and videos, use **Reduce size**.)

Documents that are compressed inside (Word, Excel, PowerPoint, OpenDocument, EPUB, PDF, ZIP) are opened up first, so the compressors see the real text:

- **Exact copy**: every part that zlib can recompress bit for bit travels uncompressed and is recompressed on the receiver. The file comes out byte-identical. This works for files made by LibreOffice, macOS, Ghostscript, LaTeX and many Java and Python tools.
- **Smallest** (offered when it is at least 10% smaller): Microsoft Office, and PDFs saved by Chrome or Edge ("Save as PDF"), Word and many scanners, compress with their own code, which zlib can't redo bit for bit. Beam sends the contents and rebuilds the document on the receiver: the same parts and pages with the same contents (each one checked), but the file's bytes differ slightly. For a PDF, Beam also moves the PDF's internal byte positions to match, so it opens normally. Before offering this, the sender builds the receiver's file itself and checks it. **Exact copy** is one tap away.

Measured on real files (Apache POI and pdf.js test files, files made by Word, Excel, PowerPoint, Chrome, LibreOffice and LaTeX, and photos). Size sent, before this version and now:

| File | Size | Before | Now | Smaller by |
|---|---|---|---|---|
| Text (a novel) | 149 KB | 48 KB | 38 KB | 21% |
| Word document (text) | 73 KB | 62 KB | 50 KB | 19% |
| Excel workbook, large | 829 KB | 208 KB | 141 KB | 32% |
| Excel workbook, formulas | 63 KB | 40 KB | 34 KB | 14% |
| PowerPoint | 46 KB | 20 KB | 17 KB | 17% |
| PDF from Chrome ("Save as PDF") | 49 KB | 45 KB | 21 KB | 52% |
| PDF from Chrome, a long table | 113 KB | 93 KB | 62 KB | 33% |
| PDF with photos (LibreOffice) | 170 KB | 159 KB | 138 KB | 13% |
| PDF from LaTeX | 992 KB | 518 KB | 487 KB | 6% |
| PowerPoint with a photo | 953 KB | 953 KB | 725 KB | 24% |
| JPEG photo, 12 MP | 3.2 MB | 3.2 MB | 2.4 MB | 23% |
| JPEG photo, phone-size | 136 KB | 136 KB | 106 KB | 22% |

Compressing takes about 0.1–3 seconds on a laptop (longest for large PDFs and photos); phones take two to three times as long.

## Password (optional)

Type a password under the chosen file before you tap **Send** or **Export**.

- Beam encrypts the file, including its name and type, before any code is made: AES-256-GCM, with the key made from the password by PBKDF2-SHA-256 (250,000 rounds) and a random salt.
- The receiver collects the codes as usual, then asks for the password. A wrong password is refused, and so is data that was changed.
- The password is never sent or saved. If it is lost, the file cannot be opened.
- Anyone who sees the codes learns only roughly how big the file is.
- Codes can be photographed and kept, so someone could try passwords for as long as they like. A short password can be guessed. Use 4 or more random words, or 12 or more characters, and tell the receiver the password another way (not written next to the codes).

## Export and import

**Export** turns the chosen file into a fixed set of codes that anyone with Beam can read: live with **Receive**, or later with **Import**.

1. Choose a file (and a password if you want). Under **Export and import**, tap **Export…**.
2. Pick a format:
   - **PDF to print**: A4 or Letter, landscape or portrait, with 1, 4 (2 × 2) or 9 (3 × 3) codes per page. Each page says its number, how many pages are enough, and where to get Beam. Several smaller codes per page hold more: zoom in on one at a time, or sweep the phone over the page.
   - **Images**: PNG files in a ZIP, to show on any screen or send on.
   - **Slideshow**: one HTML page that plays the codes in a loop on any computer or TV (full screen, pause, faster or slower).
3. Set density, colours and error correction as for Send. **Spare pieces** (none, 10%, 25% or 50%) adds repair pieces, so any part of the set is enough and some pages can be lost, torn or unreadable. **Suggested settings** and **Same as my sender settings** fill them in.
4. The dialog shows, as you change settings, how many pages, images or frames you will get, how many of them are enough, how much of the file each carries, and the download size. Raise density or colours, or lower spare pieces, for fewer; do the opposite for sturdier.
5. **Preview**: the first 25 pages, images or frames appear as you change settings, exactly as they will be exported (pages show their paper and caption). Beam reads each one back with its own reader and marks it ✓. Tap one to see it full size, and step through them. The export uses these same frames.

**Import…** reads Beam's PDF, ZIP or slideshow, or photos and screenshots of codes. Pick several at once; scanner-app PDFs with photo pages work too. Beam shows how much of the file it has and asks for more pages if some are missing. Everything is read on the device; nothing is uploaded.

**Printing.** The 4 colours use the printer's own cyan, magenta, yellow and black inks; pick 2 colours for a black-and-white printer.

| Paper settings (A4 landscape, ECC H) | Square size | Data per page | Reads with |
|---|---|---|---|
| Density 256, 4 colours (suggested) | 1.0 mm | 5.6 KB | a phone camera live, or one photo per page |
| Density 256, 8 colours | 1.0 mm | 8.4 KB | as above, with a good colour printer |
| Density 384, 4 colours | 0.7 mm | 14 KB | one photo per page (Receive, then Photo), or a 4K camera |
| Density 512, 4 colours | 0.5 mm | 26 KB | one sharp photo per page, or sweeping close |
| 4 codes per page at 384, 4 colours | 0.35 mm | 53 KB | one sharp 12 MP photo per page, or sweeping close (about 10 cm); a laser print is best |
| 9 codes per page at 256, 4 colours | 0.35 mm | 46 KB | two photos per page (top and bottom half), or sweeping close |

The export dialog says how many phone photos each page needs at the settings chosen. For images and slideshows it says how many screen pixels each square gets on a Full HD screen: a camera needs about 4.5 to read live, and below about 2.5 no camera can read it at all, because the screen itself blurs the squares together (such images still work with Import).

Paper suits small files: a 50 KB document is about 12 pages at the suggested settings, a 500 KB photo over 100. Use **Reduce size** first for photos.

Tested with simulated prints (inkjet colours, ink spread, paper grain) photographed by a simulated phone: at density 256 every block read from 12 MP photos, including 9° tilt, rotation, a 45% shadow across the page, blur and JPEG compression, and from a live 1080p camera. Sweeping a simulated phone (1080p, 10–15 cm above the page) in rows over a page of 4 codes at 0.35 mm squares received a 40 KB file in about 5 seconds. One simulated sharp 12 MP photo of that page read 301 of its 304 blocks (enough for the file on its own); of a page of 9 codes, 205 of 261. A soft (blurred) 12 MP photo of either page reads little: then take two closer photos.

**Spare pieces on paper.** With **None**, almost every block must be read: a stain or tear on a few blocks can make the file impossible to finish from those pages. Use 10% for clean prints, 25% for paper that will be handled.

## Reduce size (optional)

Shown when you pick a photo or a video. Leave it on **Original** to send the exact file.

- **Photos: Large, Medium, Small** resize to 2560, 1600 or 1024 pixels on the long side and recompress. A 3 MB phone photo usually becomes 0.1–0.5 MB.
- **Videos: 720p, 480p, 360p** re-encode in the browser with sound. It takes as long as the video plays, so keep the screen open. A 360p copy is often a tenth of the size or less.

If the result isn't smaller, Beam sends the original.

## Receiver options

- **Camera: fastest fps / 30 fps**. By default Beam asks the camera for its highest frame rate (often 60 fps on phones).
- **Camera: HD / 4K**. 4K resolves denser grids, but each frame takes longer to read.
- **Reader**: automatic (grid or QR), colour grid, built-in QR (fast on Android Chrome) or ZXing QR (works everywhere, including iPhone).

## How fast

Measured with a simulated phone camera (1080p, perspective, blur, noise, colour bleed, hand shake, torn frames), on a slow 2-core test machine. Real phones are not measured yet; tell us what the receiver shows.

| Setup | Data per frame | Measured end to end |
|---|---|---|
| QR, 1 code | up to 2.7 KB | 19 KB/s |
| QR, 2–4 codes | up to 11 KB | 36–41 KB/s |
| Grid, density 288 (312×172), 4 colours, 15 frames a second | 8 KB | 115–130 KB/s (146 KB file in 1.1–1.3 s) |
| Grid, density 256, 8 colours, 15 frames a second (speed test) | 9 KB | 133 KB/s |
| Grid at 30 frames a second, 60 fps camera | 8 KB | up to about 240 KB/s if every frame is read |

The grid kept decoding with blur, noise, a 7° tilt and 3% lens bend. When the camera catches a frame half-way through a change (a torn frame), only the blocks on the tear are lost, not the whole frame.

Text and documents are compressed first, so they often go several times faster. Videos are usually too large unless you use **Reduce size**.

## How it works

The file is cut into 180-byte chunks and sent with a fountain code:

- **Chunks**: the file's own chunks with their number, sent in order. The receiver drops each one straight into place.
- **Repair pieces**: random mixes of chunks. They fill whatever chunks the camera missed, so you never wait for the loop to come around again.

The receiver needs about as many pieces as the file has chunks, plus under 1 percent, in any order. Stitching and repair run in a background worker.

**Colour grid.** Each frame is a grid of cells in 2, 4 or 8 colours (black, cyan, magenta and yellow for 4).

- Four corner squares outline it.
- A strip along the bottom says the grid's size, colours and error correction, so the reader never has to count cells along an edge the lens may bend.
- The rest is blocks. Each block carries one piece plus its header and a CRC-16, protected by Reed-Solomon error correction. At its centre is a small black-and-white alignment mark and a ring of reference colours. The reader follows the marks across the screen to undo tilt and lens bend, and judges each block's colours against its own references, so uneven light and colour casts don't matter.
- Blocks are independent, so a torn camera frame still yields every block the tear misses.
- **Sweep reading:** with no corner squares in view, the reader finds the alignment marks themselves (a black square in a white ring), groups them into the lattice they sit on, and fits a small perspective map for each block from its neighbouring marks. Colours, error correction and block size are worked out from what it sees, and confirmed by a block passing its checksum. Every block is scrambled the same way (code version 3), so a block can be read without knowing where it sits. Codes from older Beam (version 2) still read whole. A photo is read both ways: the whole code its corner squares give, and every block the marks give, so a photo of a page with 4 or 9 codes reads all of them.

**QR mode.** Pieces travel as Base45 in QR alphanumeric mode, which every QR reader returns exactly.

**Export.** An export is a fixed run of frames from the same fountain code: every chunk once, plus the spare repair pieces. Pages are interchangeable: any set of them with as many pieces as the file has chunks, plus ten, rebuilds it (with odds of about 1000 to 1; tested on random subsets). The PDF and PNG files are written by Beam itself: indexed colour, 4 bits a pixel, not smoothed when scaled.

**Both modes.** The file name, type and a CRC-32 checksum travel with the data (inside the encryption, when there is a password); the receiver checks the checksum before showing the file. Both sides work in parallel:

- The sender draws upcoming frames in background workers, so it can show up to 60 a second.
- On the receiver (Chrome, Edge and Android), camera frames go straight from the camera to up to 3 reader workers (MediaStreamTrackProcessor). The page never copies a frame, so the camera view and buttons stay smooth. The grid reader works on the camera's own YUV frames. Frames are skipped only while every reader is busy. Other browsers, such as iPhone Safari, hand frames over from the page, one per free reader.

## Build from source

```
npm install
npm run build   # writes beam.html and ../docs/beam/index.html
npm test        # fountain code, colour grid, export and import round trips
```

The WebAssembly codecs are prebuilt in `src/codecs/` and rebuilt only when their C/C++ sources change: `src/codecs/build.sh` (PPMd and LZMA, needs clang with the wasm32 target) and `src/codecs/jpeg/build.sh` (Brunsli, needs zig: `pip install ziglang`).

## Credits

Beam includes: [zxing-wasm](https://github.com/Sec-ant/zxing-wasm) (QR reading, Apache-2.0), [pako](https://github.com/nodeca/pako) (zlib, MIT and Zlib), [zstd](https://github.com/facebook/zstd) via [zstd-wasm](https://github.com/bokuweb/zstd-wasm) (BSD and MIT), the [7-Zip LZMA SDK](https://www.7-zip.org/sdk.html) for PPMd and LZMA (public domain) and [Brunsli](https://github.com/google/brunsli) (MIT) with [Brotli](https://github.com/google/brotli)'s headers (MIT).
