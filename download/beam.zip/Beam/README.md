# Beam

Send a file from one device to another through the screen and the camera: a full-screen colour grid (or QR codes) on one device, the camera on the other. No Wi-Fi, cable, account or internet. Everything is inside `beam.html` (about 1.6 MB).

**Web link:** https://psbarik13.github.io/beam/ (downloads: https://psbarik13.github.io/beam/download/)

## Open it

| Device | Send | Receive (needs the camera) |
|---|---|---|
| PC or Mac | Double-click `beam.html` | Double-click `start-beam.bat` (Windows) or `start-beam.command` (Mac). It opens Beam at `http://localhost`, where the browser asks for the camera normally. |
| Phone | Open https://psbarik13.github.io/beam/ | Open https://psbarik13.github.io/beam/ |

Browsers often block the camera on pages opened straight from a file, without asking. That is why receiving on a computer goes through `start-beam`, which needs Node.js. If something blocks the camera, Beam says what blocked it and how to fix it. It also tells you if the device has no camera.

## Use it

1. **Sender:** choose a file, tap **Send**. Turn the screen brightness up. For a photo or video, **Reduce size** can make it much smaller first (optional).
2. **Receiver:** tap **Receive**, allow the camera, and point it at the sender's screen so the whole grid fills the view, with all four corner squares inside it. Hold the phone the same way round as the sender's screen (sideways for a laptop).
3. When it finishes, the file opens. Zoom with pinch, the mouse wheel or the + and − buttons. Tap **Save** (or **Share** on phones).

The receiver works out by itself whether the sender shows the colour grid or QR codes.

- **Live outline:** it draws an outline on the camera view around what it sees: green when the grid reads well, amber when some of it fails, red when most fails. Each block gets a dot (green read, red failed), so you can see where glare or blur is.
- **Settings advice:** during a transfer it measures what its camera can do and shows **Faster sender settings** (density, colours, error correction, speed) with the speed to expect.

## Colour grid (the default, and the fast mode)

The whole screen becomes one code: a grid of small coloured squares with a black-and-white corner square at each corner. Each frame carries 5 to 30 KB, where one QR code carries at most 2.7 KB.

- **Speed**: frames a second. 15 suits most phones; 30 if the receiving camera runs at 60 fps (the receiver tells you).
- **Density**: about how many squares along the long side (128 to 1024). The grid then fills the whole screen, so the actual count is a little higher. 288 suits a 1080p phone camera that fills its view with the grid. Go higher for 4K cameras or when the receiver says it reads cleanly; lower if it says the squares are too small.
- **Colours**: 2 (black and white, the most robust), 4 (the default) or 8 (the most data, needs a sharp camera close up).
- **Error correction**: L, M or H. Each block fixes up to 12, 18 or 27 wrong bytes of 200. Raise it if the receiver loses many blocks.
- **Hide settings** folds the panel down to one line (name, speed, Stop), and the grid grows to fill the space. **Hide everything** and **Full screen** give it the whole display.

## QR mode

Standard QR codes, for when a plain QR reader must be able to check them, or the grid doesn't read.

- **Speed**: 1 to 60 frames a second. 8 to 15 suits most cameras.
- **Density**: data per code, 180 B to 2.7 KB (QR version 40).
- **Error correction**: L, M, Q or H.
- **Codes on screen**: 1, 2, 4 or 6 codes at once, filling wide screens.

Change any setting mid-transfer, in either mode; the receiver keeps its progress.

## Speed test

Finds the fastest settings for a particular pair of devices. It runs until you stop it.

1. **Sender:** on the home screen, under **Speed test**, tap **Test pattern** (you choose the settings) or **Auto sweep**. Auto sweep loops through settings for ever, about two minutes per round: densities × 2, 4 and 8 colours at 10 frames a second, then speeds from 6 to 60 frames a second, then error correction L and H.
2. **Receiver:** tap **Receive** as usual. It sees the test frames and shows:
   - the live speed in KB/s and the share of blocks lost;
   - the sender's current settings;
   - a table of every setting measured, fastest first;
   - **Best measured** and, after an auto sweep round, **Predicted best**: the speed of each density and colour count combined with how fast this camera keeps up.

Change settings on either device whenever you like; results are kept per receiver camera setting. **Copy results** puts the table on the clipboard as CSV. The link only runs from sender to receiver, so set the recommended settings on the sender yourself.

## Reduce size (optional)

Shown when you pick a photo or a video. Leave it on **Original** to send the exact file.

- **Photos: Large, Medium, Small** resize to 2560, 1600 or 1024 pixels on the long side and recompress. A 3 MB phone photo usually becomes 0.1–0.5 MB.
- **Videos: 720p, 480p, 360p** re-encode in the browser with sound. It takes as long as the video plays, so keep the screen open. A 360p copy is often a tenth of the size or less.

If the result isn't smaller, Beam sends the original.

## Receiver options

- **Camera: fastest fps / 30 fps**. By default Beam asks the camera for its highest frame rate (often 60 fps on phones).
- **Camera: HD / 4K**. 4K resolves denser grids, but each frame takes longer to read.
- **Reader**: automatic (grid or QR), colour grid, built-in QR (fast on Android Chrome) or ZXing QR (works everywhere, including iPhone).

## How fast

Measured with a simulated phone camera (1080p, perspective, blur, noise, colour bleed, hand shake, torn frames), on a slow 2-core test machine. Real phones are not measured yet; tell us what the receiver shows.

| Setup | Data per frame | Measured end to end |
|---|---|---|
| QR, 1 code | up to 2.7 KB | 19 KB/s |
| QR, 2–4 codes | up to 11 KB | 36–41 KB/s |
| Grid, density 288 (312×172), 4 colours, 15 frames a second | 8 KB | 115–130 KB/s (146 KB file in 1.1–1.3 s) |
| Grid, density 256, 8 colours, 15 frames a second (speed test) | 9 KB | 133 KB/s |
| Grid at 30 frames a second, 60 fps camera | 8 KB | up to about 240 KB/s if every frame is read |

The grid kept decoding with blur, noise, a 7° tilt and 3% lens bend. When the camera catches a frame half-way through a change (a torn frame), only the blocks on the tear are lost, not the whole frame.

Text and documents are compressed first, so they often go several times faster. Videos are usually too large unless you use **Reduce size**.

## How it works

The file is cut into 180-byte chunks and sent with a fountain code:

- **Chunks**: the file's own chunks with their number, sent in order. The receiver drops each one straight into place.
- **Repair pieces**: random mixes of chunks. They fill whatever chunks the camera missed, so you never wait for the loop to come around again.

The receiver needs about as many pieces as the file has chunks, plus under 1 percent, in any order. Stitching and repair run in a background worker.

**Colour grid.** Each frame is a grid of cells in 2, 4 or 8 colours (black, cyan, magenta and yellow for 4).

- Four corner squares outline it.
- A strip along the bottom says the grid's size, colours and error correction, so the reader never has to count cells along an edge the lens may bend.
- The rest is blocks. Each block carries one piece plus its header and a CRC-16, protected by Reed-Solomon error correction. At its centre is a small black-and-white alignment mark and a ring of reference colours. The reader follows the marks across the screen to undo tilt and lens bend, and judges each block's colours against its own references, so uneven light and colour casts don't matter.
- Blocks are independent, so a torn camera frame still yields every block the tear misses.

**QR mode.** Pieces travel as Base45 in QR alphanumeric mode, which every QR reader returns exactly.

**Both modes.** The file name, type and a CRC-32 checksum travel with the data; the receiver checks the checksum before showing the file. Both sides work in parallel:

- The sender draws upcoming frames in background workers, so it can show up to 60 a second.
- On the receiver (Chrome, Edge and Android), camera frames go straight from the camera to up to 3 reader workers (MediaStreamTrackProcessor). The page never copies a frame, so the camera view and buttons stay smooth. The grid reader works on the camera's own YUV frames. Frames are skipped only while every reader is busy. Other browsers, such as iPhone Safari, hand frames over from the page, one per free reader.
