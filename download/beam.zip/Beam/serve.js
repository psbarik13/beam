#!/usr/bin/env node
'use strict';
// Opens Beam at http://localhost. Browsers allow the camera on localhost and ask for permission
// normally, which some of them refuse to do for pages opened straight from a file.
const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const FILE = path.join(__dirname, 'beam.html');
if (!fs.existsSync(FILE)) {
  console.error('  beam.html must be in the same folder as serve.js.');
  process.exit(1);
}

const server = http.createServer((req, res) => {
  const url = (req.url || '/').split('?')[0];
  if (url === '/' || url === '/index.html' || url === '/beam.html') {
    const data = fs.readFileSync(FILE);
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': data.length, 'Cache-Control': 'no-cache' });
    return res.end(data);
  }
  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('Not found');
});

function open(url) {
  const cmd = process.platform === 'win32' ? ['rundll32.exe', ['url.dll,FileProtocolHandler', url]]
    : process.platform === 'darwin' ? ['open', [url]] : ['xdg-open', [url]];
  try { const c = spawn(cmd[0], cmd[1], { detached: true, stdio: 'ignore' }); c.on('error', () => {}); c.unref(); } catch {}
}

let port = Number(process.argv[2]) || 8790;
server.on('error', (e) => {
  if (e.code === 'EADDRINUSE' && port < 8810) { port++; server.listen(port, '127.0.0.1'); }
  else { console.error('  Could not start: ' + e.message); process.exit(1); }
});
server.on('listening', () => {
  const url = `http://localhost:${port}/`;
  console.log('');
  console.log(`  Beam is open at ${url}`);
  console.log('  Only this computer can open that address. Keep this window open; press Ctrl+C to stop.');
  console.log('');
  open(url);
});
server.listen(port, '127.0.0.1');
