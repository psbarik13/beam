@echo off
title Beam
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Node.js is not installed. Get it from https://nodejs.org ^(LTS^), or open beam.html from its web link instead.
  echo.
  pause
  exit /b 1
)
node serve.js %*
pause
