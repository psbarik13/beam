#!/bin/bash
# Double-click to open Beam at http://localhost on macOS.
cd "$(dirname "$0")" || exit 1
export PATH="/opt/homebrew/bin:/usr/local/bin:$HOME/.volta/bin:$PATH"
[ -s "$HOME/.nvm/nvm.sh" ] && . "$HOME/.nvm/nvm.sh" >/dev/null 2>&1
if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "  Node.js is not installed. Get it from https://nodejs.org (LTS), or open beam.html from its web link instead."
  read -n 1 -s -r -p "  Press any key to close."
  exit 1
fi
node serve.js "$@"
