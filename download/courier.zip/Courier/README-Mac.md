# Courier for Mac

Same app as the Windows version: share a Mac folder with your phone over Wi-Fi.

## Steps

1. Copy this whole **Mac** folder to your Mac (for example into Documents).
2. Install Node.js from https://nodejs.org (LTS) if you don't have it.
3. Double-click **start.command**.
   - If macOS says it can't be opened because it's from an unidentified developer, right-click it, choose **Open**, then **Open** again.
   - If it says you don't have permission, open Terminal once and run `chmod +x ` followed by the file (drag start.command into the Terminal window), then press Return.
4. If macOS asks whether **node** may accept incoming network connections, click **Allow**.
5. Your browser opens the control page. Click **Choose folder**, then **Connect phone**, and scan the QR code with your phone.

Keep the Terminal window open while you transfer. Press Ctrl+C or close it to stop.

## Mac differences

- Deleted items go to the **Trash**. On macOS 14 or older, the first delete asks to let Terminal control Finder. Click **OK**.
- macOS may ask to let Terminal access Desktop, Documents or Downloads when you share or browse those folders. Click **Allow**.
- The folder browser shows external drives under their names (from /Volumes).

Everything else, including features, security and phone steps, is in README.md.
