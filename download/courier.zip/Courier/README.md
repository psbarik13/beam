# Courier

Share a folder on your PC with your phone over Wi-Fi. Pick the folder on the PC, scan a QR code with the phone, and the phone gets a file manager for that folder: upload, download, make folders, rename, delete, and watch videos or view photos straight from the PC.

No install step. Needs only Node.js 16 or newer.

## Start it

Double-click **start.bat**, or run:

```
node server.js
```

Your browser opens the control page at `http://localhost:8765/admin`.

1. Click **Choose folder** (or **Browse on this page**) and pick the folder to share.
2. Click **Connect phone**. A QR code appears.
3. Scan it with the phone's camera. The file manager opens on the phone.

The phone stays paired for 30 days, so next time just open the same page on the phone (bookmark it or add it to the home screen). The shared folder is remembered between runs.

Options:

```
node server.js --folder "D:\Phone Transfer" --port 8765 --no-open
```

## What the phone can do

- Browse folders, filter by name, sort by name, date or size, switch between list and photo grid
- **Upload** photos, videos and any file. Uploads go in 8 MB pieces and resume on their own if Wi-Fi drops. The original modified date is kept. A file that's already on the PC with the same name and size is skipped (you can upload a copy anyway).
- **Download** single files, several files, or whole folders as one ZIP (handles files over 4 GB)
- **Watch** videos and listen to audio with seeking, view photos with swipe, read text files, open PDFs
- **Open in another app** (Android) or **Open in VLC** (iPhone) for video formats the browser can't play, like many MKV/AVI/HEVC files
- New folder, rename, delete. On Windows, deleted items go to the Recycle Bin (network drives skip the Recycle Bin and delete for good).
- Long-press any item to select several

The PC page shows connected phones and a live log of every transfer. You can turn off uploading, or renaming and deleting, at any time.

## If the phone can't open the page

- Both devices must be on the **same Wi-Fi**. Guest networks often block devices from seeing each other.
- When Windows asks whether Node.js may use the network, choose **Allow** for private networks. If you missed it: Windows Security, then Firewall & network protection, then Allow an app through firewall, and tick Node.js for Private.
- In Windows Settings, set your Wi-Fi's network profile to **Private**.
- If the PC has several network adapters (VPN, WSL, VirtualBox), pick the right one in the **Network** list under the QR code.
- If Chrome warns that the connection isn't secure, that's because this runs over plain HTTP on your own network. Tap to continue.

## iPhone notes

When you upload from the Photos library, iOS may convert HEIC photos to JPEG. Files picked through **Files** are sent unchanged.

## Security

- The phone link has a random 128-bit key. Without it, other devices on the network get nothing.
- **Make a new link** on the QR card revokes every phone paired before.
- The control page only works from the PC itself (`localhost`).
- Phones can't reach anything outside the shared folder, including through shortcuts or links that point elsewhere.
- HTML files in the share are served in a sandbox so they can't run scripts against Courier.

Traffic is not encrypted (plain HTTP), so use it on networks you trust, such as your home Wi-Fi.

## Files

```
server.js          the server
lib/qr.js          QR code generator
lib/zip.js         streaming ZIP writer
lib/mime.js        file types
public/admin.html  PC control page
public/app.*       phone file manager
start.bat          double-click launcher for Windows
```

`courier.config.json` is created on first run. It stores the shared folder, settings and the phone key. Delete it to reset everything.
