(() => {
  'use strict';

  // ------------------------------------------------------------ utilities
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const icon = (id, cls = 'i') => `<svg class="${cls}" aria-hidden="true"><use href="#i-${id}"/></svg>`;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const UA = navigator.userAgent;
  const IS_ANDROID = /Android/i.test(UA);
  const IS_IOS = /iPhone|iPad|iPod/.test(UA) || (/Macintosh/.test(UA) && navigator.maxTouchPoints > 1);
  const collator = new Intl.Collator(undefined, { numeric: true, sensitivity: 'base' });

  function store(k, d) {
    try { const v = localStorage.getItem('courier.' + k); return v == null ? d : JSON.parse(v); } catch { return d; }
  }
  function keep(k, v) {
    try { localStorage.setItem('courier.' + k, JSON.stringify(v)); } catch {}
  }

  function fmtBytes(n) {
    if (n == null) return '';
    const u = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
    return (n < 10 && i ? n.toFixed(1) : Math.round(n)) + ' ' + u[i];
  }
  function fmtDate(ms) {
    const d = new Date(ms);
    const now = new Date();
    const time = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    if (d.toDateString() === now.toDateString()) return 'Today, ' + time;
    const opts = d.getFullYear() === now.getFullYear() ? { day: 'numeric', month: 'short' } : { day: 'numeric', month: 'short', year: 'numeric' };
    return d.toLocaleDateString([], opts) + ', ' + time;
  }
  function fmtDuration(sec) {
    if (!isFinite(sec) || sec <= 0) return '';
    if (sec < 60) return 'under a minute left';
    if (sec < 3600) return 'about ' + Math.round(sec / 60) + ' min left';
    return 'about ' + (sec / 3600).toFixed(1) + ' h left';
  }
  const plural = (n, one, many) => n + ' ' + (n === 1 ? one : many || one + 's');

  const joinPath = (dir, name) => (dir === '/' ? '' : dir) + '/' + name;
  const parentOf = (p) => (p === '/' ? '/' : p.slice(0, p.lastIndexOf('/')) || '/');
  const encPath = (p) => p.split('/').map(encodeURIComponent).join('/');
  const fileUrl = (p, query = '') => '/f' + encPath(p) + query;
  const toHash = (p) => '#' + encPath(p);
  function fromHash() {
    const h = location.hash.slice(1);
    if (!h || h === 'unpaired') return '/';
    try { return '/' + h.split('/').filter(Boolean).map(decodeURIComponent).join('/'); } catch { return '/'; }
  }

  // ------------------------------------------------------------ state
  const S = {
    info: null,
    path: '/',
    entries: [],
    shown: [],
    free: null,
    rootName: '',
    sort: store('sort', 'name'),
    view: store('view', 'list'),
    hidden: store('hidden', false),
    filter: '',
    selecting: false,
    selected: new Set(),
    loadSeq: 0,
    loaded: false,
  };

  // ------------------------------------------------------------ API
  class ApiError extends Error {
    constructor(status, message, data) { super(message); this.status = status; this.data = data || {}; }
  }

  async function call(method, url, body) {
    let res;
    try {
      res = await fetch(url, {
        method,
        headers: body ? { 'Content-Type': 'application/json' } : {},
        body: body ? JSON.stringify(body) : undefined,
        credentials: 'same-origin',
        cache: 'no-store',
      });
    } catch {
      setOffline(true);
      throw new ApiError(0, 'Can’t reach your PC.');
    }
    setOffline(false);
    const data = await res.json().catch(() => ({}));
    if (res.status === 401) {
      showGate('unpaired');
      throw new ApiError(401, data.error || 'Not connected.');
    }
    if (!res.ok) throw new ApiError(res.status, data.error || 'The PC returned an error (' + res.status + ').', data);
    return data;
  }
  const get = (url) => call('GET', url);
  const post = (url, body) => call('POST', url, body || {});

  // ------------------------------------------------------------ gate / offline
  function showGate(kind) {
    const g = $('gate');
    if (kind === 'unpaired') {
      $('gateTitle').textContent = 'Scan the QR code on your PC';
      $('gateBody').textContent = 'This phone isn’t connected. On your PC, open Courier, click Connect phone, and scan the code with your camera.';
    } else if (kind === 'noroot') {
      $('gateTitle').textContent = 'Your PC isn’t sharing a folder yet';
      $('gateBody').textContent = 'On your PC, open Courier and choose the folder to share. Then try again.';
    } else {
      $('gateTitle').textContent = 'Can’t reach your PC';
      $('gateBody').textContent = 'Check that Courier is still running on the PC and that both devices are on the same Wi-Fi.';
    }
    g.dataset.kind = kind;
    g.hidden = false;
  }
  function hideGate() { $('gate').hidden = true; }
  $('gateRetry').addEventListener('click', () => boot());

  function setOffline(on) {
    if (!S.loaded) { if (on) showGate('offline'); return; }
    $('offline').hidden = !on;
  }
  $('offlineRetry').addEventListener('click', () => load(S.path, { keep: true }));

  // ------------------------------------------------------------ toast
  let toastTimer;
  function toast(msg, isErr) {
    const t = $('toast');
    t.textContent = msg;
    t.className = 'toast' + (isErr ? ' err' : '');
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { t.hidden = true; }, isErr ? 5500 : 2800);
  }

  // ------------------------------------------------------------ overlays + back button
  // Every sheet, dialog and the viewer gets a history entry so Android's back button closes it.
  const stack = [];
  let afterPop = [];
  if (history.state && history.state.ov) history.replaceState(null, '');

  function overlayOpen(onClose, { replace } = {}) {
    if (replace) history.replaceState({ ov: stack.length + 1 }, '');
    else history.pushState({ ov: stack.length + 1 }, '');
    stack.push(onClose);
    document.body.classList.add('locked');
  }
  function overlayClose(then) {
    if (!stack.length) { if (then) then(); return; }
    if (then) afterPop.push(then);
    history.back();
  }
  // Remove the top overlay without touching history; the caller must reuse the entry.
  function overlayDetach() {
    const fn = stack.pop();
    if (fn) fn();
  }
  window.addEventListener('popstate', () => {
    const depth = (history.state && history.state.ov) || 0;
    while (stack.length > depth) stack.pop()();
    if (!stack.length) document.body.classList.remove('locked');
    const run = afterPop;
    afterPop = [];
    run.forEach((fn) => fn());
  });

  function layer(html, { center } = {}) {
    const el = document.createElement('div');
    el.className = 'layer' + (center ? ' center' : '');
    el.innerHTML = '<div class="scrim"></div>' + html;
    $('layers').appendChild(el);
    el.querySelector('.scrim').addEventListener('click', overlayClose);
    return el;
  }

  // items: [{ label, icon, danger, href, download, target, opens, run, on }]
  function sheet({ title, sub, items, html }) {
    const visible = items.filter((it) => it && !it.hidden);
    const el = layer(`<div class="sheet" role="menu">
      ${title ? `<div class="sheet-head"><b>${esc(title)}</b>${sub ? `<span>${esc(sub)}</span>` : ''}</div>` : ''}
      ${html || ''}
      ${visible.map((it, i) => it.section
        ? `<div class="sheet-label">${esc(it.section)}</div>`
        : it.href
          ? `<a class="sheet-item ${it.danger ? 'danger' : ''}" role="menuitem" data-i="${i}" href="${esc(it.href)}" ${it.download ? 'download' : ''} ${it.target ? `target="${it.target}"` : ''}>${icon(it.icon)}<span>${esc(it.label)}</span></a>`
          : `<button class="sheet-item ${it.danger ? 'danger' : ''}" role="menuitem" type="button" data-i="${i}">${icon(it.icon)}<span>${esc(it.label)}</span>${it.on ? `<span class="on">${icon('check')}</span>` : ''}</button>`).join('')}
    </div>`);
    overlayOpen(() => el.remove());
    el.querySelector('.sheet').addEventListener('click', (e) => {
      const b = e.target.closest('[data-i]');
      if (!b) return;
      const it = visible[Number(b.dataset.i)];
      if (it.opens) {
        overlayDetach();
        it.run({ replace: true });
      } else if (it.href) {
        setTimeout(() => overlayClose(), 60);
      } else {
        e.preventDefault();
        overlayClose(() => it.run && it.run({}));
      }
    });
  }

  function dialog({ title, body, input, okLabel = 'OK', danger, replace, validate, selectBase }) {
    return new Promise((resolve) => {
      let result = null;
      const el = layer(`<form class="dialog" role="dialog" aria-modal="true">
        <h2>${esc(title)}</h2>
        ${body ? `<p>${esc(body)}</p>` : ''}
        ${input != null ? `<input type="text" name="v" value="${esc(input)}" autocomplete="off" autocapitalize="off" spellcheck="false"><div class="err" aria-live="polite"></div>` : ''}
        <div class="btns">
          <button class="btn" type="button" data-cancel>Cancel</button>
          <button class="btn ${danger ? 'danger solid' : 'primary'}" type="submit">${esc(okLabel)}</button>
        </div>
      </form>`, { center: true });
      overlayOpen(() => { el.remove(); resolve(result); }, { replace });
      const form = el.querySelector('form');
      const field = form.querySelector('input');
      if (field) {
        setTimeout(() => {
          field.focus();
          const dot = selectBase ? field.value.lastIndexOf('.') : -1;
          field.setSelectionRange(0, dot > 0 ? dot : field.value.length);
        }, 60);
      }
      form.querySelector('[data-cancel]').addEventListener('click', overlayClose);
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const v = field ? field.value.trim() : true;
        if (field) {
          const problem = !v ? 'Enter a name.' : validate ? validate(v) : '';
          if (problem) { form.querySelector('.err').textContent = problem; return; }
        }
        result = v;
        overlayClose();
      });
    });
  }

  // ------------------------------------------------------------ loading + rendering
  async function load(p, { keep: keepState } = {}) {
    const seq = ++S.loadSeq;
    if (!keepState) renderSkeleton();
    try {
      const data = await get('/api/list?path=' + encodeURIComponent(p) + (S.hidden ? '&hidden=1' : ''));
      if (seq !== S.loadSeq) return;
      const changedDir = data.path !== S.path;
      S.path = data.path;
      S.entries = data.entries;
      S.free = data.free;
      S.rootName = data.rootName || 'Shared folder';
      if (S.info && data.rootId !== S.info.rootId) {
        S.info.rootId = data.rootId;
        if (S.path !== '/') return go('/');
      }
      S.loaded = true;
      hideGate();
      $('offline').hidden = true;
      if (changedDir || !keepState) {
        exitSelect(true);
        S.filter = '';
        $('search').value = '';
        $('searchRow').hidden = true;
        window.scrollTo(0, 0);
      } else {
        for (const n of [...S.selected]) if (!S.entries.some((e) => e.name === n)) S.selected.delete(n);
      }
      render();
    } catch (e) {
      if (seq !== S.loadSeq) return;
      if (e.status === 404 && p !== '/') { toast(e.message, true); go(parentOf(p)); return; }
      if (e.status === 409) { showGate('noroot'); return; }
      if (e.status && e.status !== 401) toast(e.message, true);
      if (!keepState) renderList();
    }
  }

  function go(p) {
    const h = toHash(p);
    if (location.hash === h) load(p);
    else location.hash = h;
  }
  window.addEventListener('hashchange', () => {
    if (location.hash === '#unpaired') return;
    load(fromHash());
  });

  function sortedEntries() {
    let list = S.entries.slice();
    const f = S.filter.trim().toLowerCase();
    if (f) list = list.filter((e) => e.name.toLowerCase().includes(f));
    const byName = (a, b) => collator.compare(a.name, b.name);
    const cmp = {
      name: byName,
      date: (a, b) => b.mtime - a.mtime || byName(a, b),
      size: (a, b) => (a.dir && b.dir ? byName(a, b) : (b.size || 0) - (a.size || 0) || byName(a, b)),
    }[S.sort] || byName;
    return list.sort((a, b) => (b.dir - a.dir) || cmp(a, b));
  }

  const KIND_ICON = {
    folder: 'folder', image: 'image', rawimage: 'image', video: 'video', audio: 'audio', pdf: 'pdf', text: 'text',
    doc: 'doc', sheet: 'sheet', slides: 'slides', archive: 'archive', apk: 'apk', file: 'file',
  };
  const VIEWABLE = new Set(['image', 'rawimage', 'video', 'audio', 'text', 'pdf']);

  function render() {
    renderHeader();
    renderList();
    renderBars();
  }

  function renderHeader() {
    const parts = S.path.split('/').filter(Boolean);
    const crumbs = [`<button type="button" data-p="/">${esc(S.rootName)}</button>`];
    let acc = '';
    for (const part of parts) {
      acc += '/' + part;
      crumbs.push(`<span class="sep">/</span><button type="button" data-p="${esc(acc)}">${esc(part)}</button>`);
    }
    const c = $('crumbs');
    c.innerHTML = parts.length ? crumbs.join('') : `<span>${esc(S.info ? 'On ' + S.info.pcName : '')}</span>`;
    c.scrollLeft = c.scrollWidth;
    $('title').textContent = parts.length ? parts[parts.length - 1] : S.rootName;
    $('upBtn').hidden = !parts.length;
    document.title = (parts.length ? parts[parts.length - 1] : S.rootName) + ' – Courier';

    const dirs = S.entries.filter((e) => e.dir).length;
    const files = S.entries.length - dirs;
    const bits = [];
    if (dirs) bits.push(plural(dirs, 'folder'));
    if (files) bits.push(plural(files, 'file'));
    if (!bits.length) bits.push('Empty');
    $('subrow').innerHTML = `<span>${esc(bits.join(', '))}</span><span class="spacer"></span><span>${esc({ name: 'Name', date: 'Newest first', size: 'Largest first' }[S.sort])}</span>`;
  }

  function thumbHtml(e, p) {
    if (e.dir) return `<span class="thumb folder">${icon('folder')}</span>`;
    if (e.kind === 'image' && S.view === 'list' && e.size < 3 * 1024 * 1024) {
      return `<span class="thumb"><img loading="lazy" decoding="async" alt="" src="${esc(fileUrl(p))}" onerror="this.remove()"></span>`;
    }
    const badge = e.kind === 'video' ? `<span class="badge">${icon('play')}</span>` : '';
    return `<span class="thumb">${icon(KIND_ICON[e.kind] || 'file')}${badge}</span>`;
  }

  function renderList() {
    const list = $('list');
    S.shown = sortedEntries();
    list.className = 'list' + (S.view === 'grid' ? ' grid' : '');
    if (!S.entries.length) {
      const canUp = S.info && S.info.allowUpload;
      list.className = 'list';
      list.innerHTML = `<div class="empty-state">${icon('folder', 'big')}
        <h2>This folder is empty</h2>
        <p>${canUp ? 'Upload files from your phone or make a folder.' : 'Nothing has been shared here yet.'}</p>
        ${canUp ? `<div class="btns"><button class="btn primary" type="button" data-empty="upload">${icon('upload')}Upload</button></div>` : ''}
      </div>`;
      return;
    }
    if (!S.shown.length) {
      list.className = 'list';
      list.innerHTML = `<div class="empty-state"><h2>No matches</h2><p>Nothing in this folder has “${esc(S.filter)}” in its name.</p></div>`;
      return;
    }
    const html = S.shown.map((e, i) => {
      const p = joinPath(S.path, e.name);
      const sel = S.selected.has(e.name);
      if (S.view === 'grid') {
        const visual = e.kind === 'image'
          ? `<span class="ph">${icon('image')}</span><img loading="lazy" decoding="async" alt="" src="${esc(fileUrl(p))}" onerror="this.remove()">`
          : `<span class="ph">${icon(KIND_ICON[e.kind] || 'file')}</span>`;
        return `<div class="tile ${e.dir ? 'folder' : ''} ${e.kind === 'image' ? '' : 'plain'} ${sel ? 'sel' : ''}" data-i="${i}" role="button" tabindex="0" aria-label="${esc(e.name)}">
          ${visual}${e.kind === 'video' ? `<span class="playmark">${icon('play')}</span>` : ''}
          ${S.selecting ? `<span class="check">${icon('check')}</span>` : ''}
          <span class="cap">${esc(e.name)}</span></div>`;
      }
      const meta = e.dir ? `<span>${esc(fmtDate(e.mtime))}</span>` : `<span>${esc(fmtBytes(e.size))}</span><span>${esc(fmtDate(e.mtime))}</span>`;
      const tail = S.selecting
        ? `<span class="check">${icon('check')}</span>`
        : `<button class="iconbtn more" type="button" data-more="${i}" aria-label="Options for ${esc(e.name)}">${icon('more')}</button>`;
      return `<div class="row ${sel ? 'sel' : ''}" data-i="${i}" role="button" tabindex="0">
        ${thumbHtml(e, p)}
        <span class="text"><span class="name">${esc(e.name)}</span><span class="meta">${meta}</span></span>
        ${tail}</div>`;
    }).join('');
    const free = S.free != null ? `<div class="footer-note">${esc(fmtBytes(S.free))} free on ${esc(S.info ? S.info.pcName : 'the PC')}</div>` : '';
    list.innerHTML = html + free;
  }

  function renderSkeleton() {
    const list = $('list');
    list.className = 'list skeleton';
    list.innerHTML = Array.from({ length: 7 }, () => '<div class="row"><span class="thumb"></span><span class="text"><span class="name" style="display:block">&nbsp;</span><span class="meta">&nbsp;</span></span><span></span></div>').join('');
  }

  function renderBars() {
    const info = S.info || {};
    $('bottom').hidden = S.selecting;
    $('selActions').hidden = !S.selecting;
    $('selbar').hidden = !S.selecting;
    $('appbar').hidden = S.selecting;
    $('mkdirBtn').hidden = !info.allowUpload;
    $('uploadBtn').hidden = !info.allowUpload;
    $('bottom').classList.toggle('single', !info.allowUpload);
    if (!info.allowUpload) {
      $('bottom').hidden = true;
      document.body.style.paddingBottom = $('tray').hidden ? '24px' : '';
    } else {
      document.body.style.paddingBottom = '';
    }
    if (S.selecting) {
      const n = S.selected.size;
      $('selCount').textContent = n ? n + ' selected' : 'Select items';
      $('selAll').textContent = n === S.shown.length && n ? 'Select none' : 'Select all';
      const acts = $('selActions');
      acts.querySelector('[data-act="download"]').disabled = !n;
      acts.querySelector('[data-act="rename"]').disabled = n !== 1 || !info.allowModify;
      acts.querySelector('[data-act="delete"]').disabled = !n || !info.allowModify;
      acts.querySelector('[data-act="rename"]').hidden = !info.allowModify;
      acts.querySelector('[data-act="delete"]').hidden = !info.allowModify;
      acts.style.gridTemplateColumns = info.allowModify ? '' : '1fr';
    }
  }

  // ------------------------------------------------------------ list interactions
  let pressTimer = null;
  let pressStart = null;
  let suppressClick = false;

  const listEl = $('list');
  listEl.addEventListener('pointerdown', (e) => {
    suppressClick = false;
    const item = e.target.closest('[data-i]');
    if (!item || e.target.closest('[data-more]')) return;
    pressStart = { x: e.clientX, y: e.clientY };
    clearTimeout(pressTimer);
    pressTimer = setTimeout(() => {
      pressTimer = null;
      suppressClick = true;
      if (navigator.vibrate) navigator.vibrate(12);
      const entry = S.shown[Number(item.dataset.i)];
      if (!S.selecting) enterSelect();
      toggleSelect(entry.name);
    }, 480);
  });
  const cancelPress = () => { clearTimeout(pressTimer); pressTimer = null; };
  listEl.addEventListener('pointermove', (e) => {
    if (pressTimer && pressStart && Math.hypot(e.clientX - pressStart.x, e.clientY - pressStart.y) > 10) cancelPress();
  });
  listEl.addEventListener('pointerup', cancelPress);
  listEl.addEventListener('pointercancel', cancelPress);
  listEl.addEventListener('contextmenu', (e) => { if (e.target.closest('[data-i]') && e.pointerType !== 'mouse') e.preventDefault(); });

  listEl.addEventListener('click', (e) => {
    if (suppressClick) { suppressClick = false; return; }
    const emptyBtn = e.target.closest('[data-empty]');
    if (emptyBtn) return chooseUpload();
    const more = e.target.closest('[data-more]');
    if (more) return entryMenu(S.shown[Number(more.dataset.more)]);
    const item = e.target.closest('[data-i]');
    if (!item) return;
    const entry = S.shown[Number(item.dataset.i)];
    if (S.selecting) return toggleSelect(entry.name);
    openEntry(entry);
  });
  listEl.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    const item = e.target.closest('[data-i]');
    if (item) item.click();
  });

  function openEntry(entry) {
    if (entry.dir) return go(joinPath(S.path, entry.name));
    if (VIEWABLE.has(entry.kind)) return openViewer(entry);
    entryMenu(entry);
  }

  function entryMenu(entry) {
    const p = joinPath(S.path, entry.name);
    const info = S.info || {};
    const media = entry.kind === 'video' || entry.kind === 'audio';
    sheet({
      title: entry.name,
      sub: entry.dir ? fmtDate(entry.mtime) : fmtBytes(entry.size) + ', ' + fmtDate(entry.mtime),
      items: [
        entry.dir ? { label: 'Open', icon: 'folder', run: () => go(p) } : null,
        !entry.dir && VIEWABLE.has(entry.kind) ? { label: media ? 'Play' : 'View', icon: media ? 'play' : 'eye', opens: true, run: (o) => openViewer(entry, o) } : null,
        entry.dir ? { label: 'Download as ZIP', icon: 'zip', run: () => downloadZip([entry.name]) } : { label: 'Download', icon: 'download', href: fileUrl(p, '?dl=1'), download: true },
        media && (IS_ANDROID || IS_IOS) ? { label: IS_IOS ? 'Open in VLC' : 'Open in another app', icon: 'external', href: appUrl(p, entry.kind) } : null,
        { label: 'Select', icon: 'select', opens: true, run: (o) => { enterSelect(o); toggleSelect(entry.name); } },
        { label: 'Rename', icon: 'pen', hidden: !info.allowModify, opens: true, run: (o) => renameEntry(entry, o) },
        { label: 'Details', icon: 'info', opens: true, run: (o) => detailsSheet(entry, o) },
        { label: 'Delete', icon: 'trash', danger: true, hidden: !info.allowModify, opens: true, run: (o) => deleteEntries([entry.name], o) },
      ].filter(Boolean),
    });
  }

  function detailsSheet(entry, o = {}) {
    const p = joinPath(S.path, entry.name);
    const link = location.origin + fileUrl(p, '?k=' + encodeURIComponent(S.info.token));
    const el = layer(`<div class="sheet">
      <div class="sheet-head"><b>${esc(entry.name)}</b><span>${entry.dir ? 'Folder' : esc(fmtBytes(entry.size))}</span></div>
      <dl class="sheet-info">
        <dt>Location</dt><dd>${esc(S.rootName + p)}</dd>
        <dt>Modified</dt><dd>${esc(new Date(entry.mtime).toLocaleString())}</dd>
        ${entry.dir ? '' : `<dt>Size</dt><dd>${esc(entry.size.toLocaleString())} bytes</dd>
        <dt>Stream link for players like VLC</dt><dd><input type="text" readonly value="${esc(link)}" onfocus="this.select()"></dd>`}
      </dl>
    </div>`);
    overlayOpen(() => el.remove(), o);
  }

  // ------------------------------------------------------------ selection
  function enterSelect(o = {}) {
    if (S.selecting) return;
    S.selecting = true;
    S.selected.clear();
    overlayOpen(() => exitSelect(true), o);
    document.body.classList.remove('locked');
    render();
  }
  function exitSelect(fromHistory) {
    if (!S.selecting) return;
    if (!fromHistory) return overlayClose();
    S.selecting = false;
    S.selected.clear();
    render();
  }
  function toggleSelect(name) {
    if (S.selected.has(name)) S.selected.delete(name);
    else S.selected.add(name);
    renderList();
    renderBars();
  }
  $('selClose').addEventListener('click', () => exitSelect(false));
  $('selAll').addEventListener('click', () => {
    if (S.selected.size === S.shown.length) S.selected.clear();
    else S.shown.forEach((e) => S.selected.add(e.name));
    renderList();
    renderBars();
  });
  $('selActions').addEventListener('click', (e) => {
    const b = e.target.closest('[data-act]');
    if (!b || b.disabled) return;
    const names = [...S.selected];
    const entries = S.entries.filter((x) => S.selected.has(x.name));
    if (b.dataset.act === 'download') {
      if (entries.length === 1 && !entries[0].dir) {
        triggerDownload(fileUrl(joinPath(S.path, entries[0].name), '?dl=1'));
        exitSelect(false);
        return;
      }
      const files = entries.filter((x) => !x.dir);
      sheet({
        title: `Download ${plural(entries.length, 'item')}`,
        items: [
          { label: 'As one ZIP file', icon: 'zip', run: () => { downloadZip(names); exitSelect(false); } },
          files.length === entries.length && files.length <= 20
            ? { label: 'As separate files', icon: 'download', run: () => { downloadMany(files); exitSelect(false); } }
            : null,
        ].filter(Boolean),
      });
    } else if (b.dataset.act === 'rename' && entries.length === 1) {
      renameEntry(entries[0]);
    } else if (b.dataset.act === 'delete') {
      deleteEntries(names);
    }
  });

  // ------------------------------------------------------------ file operations
  function validateName(v) {
    if (/[<>:"/\\|?*]/.test(v)) return 'Names can’t contain < > : " / \\ | ? *';
    if (/[. ]$/.test(v)) return 'Names can’t end with a dot or a space.';
    return '';
  }

  async function makeFolder() {
    const name = await dialog({ title: 'New folder', input: '', okLabel: 'Create', validate: validateName });
    if (!name) return;
    try {
      const r = await post('/api/mkdir', { path: S.path, name });
      toast('Created ' + r.name);
      await load(S.path, { keep: true });
    } catch (e) { toast(e.message, true); }
  }

  async function renameEntry(entry, o = {}) {
    const to = await dialog({ title: 'Rename', input: entry.name, okLabel: 'Rename', validate: validateName, selectBase: !entry.dir, replace: o.replace });
    if (!to || to === entry.name) return;
    try {
      const r = await post('/api/rename', { path: S.path, from: entry.name, to });
      toast('Renamed to ' + r.name);
      if (S.selecting) exitSelect(false);
      await load(S.path, { keep: true });
    } catch (e) { toast(e.message, true); }
  }

  async function deleteEntries(names, o = {}) {
    const what = names.length === 1 ? `“${names[0]}”` : plural(names.length, 'item');
    const bin = S.info && { recycle: 'Recycle Bin', trash: 'Trash' }[S.info.trash];
    const where = bin ? `It goes to the ${bin} on ${S.info.pcName}.` : 'This can’t be undone.';
    const ok = await dialog({
      title: `Delete ${what}?`,
      body: names.length === 1 ? where : where.replace('It goes', 'They go'),
      okLabel: 'Delete',
      danger: true,
      replace: o.replace,
    });
    if (!ok) return false;
    try {
      await post('/api/delete', { path: S.path, names });
      toast(names.length === 1 ? 'Deleted ' + names[0] : 'Deleted ' + plural(names.length, 'item'));
      if (S.selecting) exitSelect(false);
      await load(S.path, { keep: true });
      return true;
    } catch (e) {
      toast(e.message, true);
      return false;
    }
  }

  function triggerDownload(href) {
    const a = document.createElement('a');
    a.href = href;
    a.download = '';
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  async function downloadMany(files) {
    toast(`Starting ${plural(files.length, 'download')}…`);
    for (const f of files) {
      triggerDownload(fileUrl(joinPath(S.path, f.name), '?dl=1'));
      await sleep(700);
    }
  }

  function downloadZip(names) {
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '/api/zip';
    form.target = IS_IOS ? '_self' : 'dlframe';
    form.hidden = true;
    const add = (k, v) => { const i = document.createElement('input'); i.type = 'hidden'; i.name = k; i.value = v; form.appendChild(i); };
    add('path', S.path);
    names.forEach((n) => add('names', n));
    document.body.appendChild(form);
    form.submit();
    form.remove();
    toast('Preparing ZIP. The download starts in a moment.');
  }

  function appUrl(p, kind) {
    const q = '?k=' + encodeURIComponent(S.info.token);
    if (IS_ANDROID) {
      return `intent://${location.host}${fileUrl(p, q)}#Intent;scheme=http;type=${kind === 'audio' ? 'audio' : 'video'}/*;end`;
    }
    const abs = location.origin + fileUrl(p, q);
    if (IS_IOS) return 'vlc-x-callback://x-callback-url/stream?url=' + encodeURIComponent(abs);
    return abs;
  }

  // ------------------------------------------------------------ header buttons
  $('upBtn').addEventListener('click', () => go(parentOf(S.path)));
  $('crumbs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-p]');
    if (b) go(b.dataset.p);
  });
  $('searchBtn').addEventListener('click', () => {
    const row = $('searchRow');
    row.hidden = !row.hidden;
    $('searchBtn').setAttribute('aria-expanded', String(!row.hidden));
    if (!row.hidden) $('search').focus();
    else if (S.filter) { S.filter = ''; $('search').value = ''; renderList(); }
  });
  $('search').addEventListener('input', (e) => { S.filter = e.target.value; renderList(); });
  window.addEventListener('scroll', () => $('appbar').classList.toggle('scrolled', window.scrollY > 4), { passive: true });

  $('menuBtn').addEventListener('click', () => {
    const set = (k, v) => { S[k] = v; keep(k, v); };
    sheet({
      items: [
        { section: 'Sort' },
        { label: 'Name', icon: 'list', on: S.sort === 'name', run: () => { set('sort', 'name'); render(); } },
        { label: 'Newest first', icon: 'refresh', on: S.sort === 'date', run: () => { set('sort', 'date'); render(); } },
        { label: 'Largest first', icon: 'download', on: S.sort === 'size', run: () => { set('sort', 'size'); render(); } },
        { section: 'View' },
        { label: 'List', icon: 'list', on: S.view === 'list', run: () => { set('view', 'list'); renderList(); } },
        { label: 'Grid with previews', icon: 'grid', on: S.view === 'grid', run: () => { set('view', 'grid'); renderList(); } },
        { label: 'Show hidden files', icon: 'eye', on: S.hidden, run: () => { set('hidden', !S.hidden); load(S.path, { keep: true }); } },
        { section: S.info ? 'Connected to ' + S.info.pcName : '' },
        { label: 'Select items', icon: 'select', opens: true, run: (o) => enterSelect(o) },
        { label: 'Refresh', icon: 'refresh', run: () => load(S.path, { keep: true }) },
      ],
    });
  });

  // ------------------------------------------------------------ uploads
  const Q = { items: [], active: 0, max: 2, seq: 0, samples: [], expanded: false };

  function chooseUpload() {
    const supportsDir = 'webkitdirectory' in document.createElement('input') && !IS_IOS && !IS_ANDROID;
    sheet({
      title: 'Upload to ' + (S.path === '/' ? S.rootName : S.path.split('/').pop()),
      items: [
        { label: 'Photos and videos', icon: 'image', run: () => $('pickMedia').click() },
        { label: 'Files', icon: 'file', run: () => $('pickAny').click() },
        supportsDir ? { label: 'A whole folder', icon: 'folder', run: () => $('pickDir').click() } : null,
      ].filter(Boolean),
    });
  }
  for (const id of ['pickMedia', 'pickAny', 'pickDir']) {
    $(id).addEventListener('change', (e) => {
      const files = [...e.target.files];
      e.target.value = '';
      if (files.length) enqueue(files, S.path);
    });
  }
  $('uploadBtn').addEventListener('click', chooseUpload);
  $('mkdirBtn').addEventListener('click', makeFolder);

  function enqueue(files, dir) {
    if (!S.info || !S.info.allowUpload) return toast('Uploading is turned off on the PC.', true);
    for (const file of files) {
      Q.items.push({
        id: ++Q.seq, file, dir, name: file.webkitRelativePath || file.name, size: file.size,
        sent: 0, status: 'queued', error: '', xhr: null, sid: null, force: false,
      });
    }
    $('tray').hidden = false;
    pump();
  }

  function pump() {
    while (Q.active < Q.max) {
      const it = Q.items.find((i) => i.status === 'queued');
      if (!it) break;
      Q.active++;
      it.status = 'uploading';
      uploadOne(it).finally(() => { Q.active--; it.xhr = null; pump(); });
    }
    renderTray();
  }

  async function postRetry(url, body, it) {
    for (let attempt = 0; ; attempt++) {
      try {
        return await post(url, body);
      } catch (e) {
        if (it.status === 'cancelled') throw e;
        if (e.status !== 0 || attempt >= 6) throw e;
        it.status = 'retrying';
        renderTray();
        await waitOnline();
        await sleep(Math.min(15000, 1000 * 2 ** attempt));
        if (it.status === 'cancelled') throw e;
        it.status = 'uploading';
      }
    }
  }

  function waitOnline() {
    if (navigator.onLine !== false) return Promise.resolve();
    return new Promise((r) => window.addEventListener('online', r, { once: true }));
  }

  function putChunk(it, offset, blob) {
    return new Promise((resolve, reject) => {
      const x = new XMLHttpRequest();
      it.xhr = x;
      x.open('PUT', `/api/upload/chunk?id=${encodeURIComponent(it.sid)}&offset=${offset}`);
      x.setRequestHeader('Content-Type', 'application/octet-stream');
      x.upload.onprogress = (e) => { it.sent = offset + e.loaded; scheduleTray(); };
      x.onload = () => {
        let data = {};
        try { data = JSON.parse(x.responseText); } catch {}
        if (x.status === 200) return resolve(data);
        if (x.status === 401) showGate('unpaired');
        reject(new ApiError(x.status, data.error || 'Upload failed (' + x.status + ').', data));
      };
      x.onerror = () => reject(new ApiError(0, 'Network error.'));
      x.ontimeout = () => reject(new ApiError(0, 'Timed out.'));
      x.onabort = () => reject(new ApiError(-1, 'Cancelled.'));
      x.timeout = 5 * 60 * 1000;
      x.send(blob);
    });
  }

  async function uploadOne(it) {
    const initBody = () => ({ path: it.dir, name: it.name, size: it.size, mtime: it.file.lastModified || 0, force: it.force });
    try {
      let init = await postRetry('/api/upload/init', initBody(), it);
      if (init.exists) {
        it.status = 'skipped';
        it.sent = it.size;
        return;
      }
      it.sid = init.id;
      let offset = init.offset;
      const chunk = init.chunkSize || (S.info && S.info.chunkSize) || 8 * 1024 * 1024;
      let failures = 0;
      for (;;) {
        while (offset < it.size) {
          if (it.status === 'cancelled') return;
          const end = Math.min(offset + chunk, it.size);
          try {
            const r = await putChunk(it, offset, it.file.slice(offset, end));
            offset = r.offset;
            failures = 0;
          } catch (e) {
            if (it.status === 'cancelled') return;
            if (e.status === 409 && typeof e.data.offset === 'number') { offset = e.data.offset; continue; }
            if (e.status === 404) {
              init = await postRetry('/api/upload/init', initBody(), it);
              it.sid = init.id;
              offset = init.offset;
              continue;
            }
            if (e.status > 0 && e.status < 500) throw e;
            failures++;
            if (failures > 8) throw new Error('Lost the connection to the PC.');
            it.status = 'retrying';
            renderTray();
            await waitOnline();
            await sleep(Math.min(15000, 1000 * 2 ** (failures - 1)));
            if (it.status === 'cancelled') return;
            it.status = 'uploading';
            init = await postRetry('/api/upload/init', initBody(), it);
            it.sid = init.id;
            offset = init.offset;
          }
          it.sent = offset;
          scheduleTray();
        }
        try {
          const fin = await postRetry('/api/upload/finish', { id: it.sid }, it);
          it.finalName = fin.name;
          it.status = 'done';
          it.sent = it.size;
          refreshSoon(it.dir);
          return;
        } catch (e) {
          if (e.status === 409 && typeof e.data.offset === 'number') { offset = e.data.offset; continue; }
          if (e.status === 404) {
            init = await postRetry('/api/upload/init', initBody(), it);
            if (init.exists) { it.status = 'done'; it.sent = it.size; refreshSoon(it.dir); return; }
            it.sid = init.id;
            offset = init.offset;
            continue;
          }
          throw e;
        }
      }
    } catch (e) {
      if (it.status !== 'cancelled') {
        it.status = 'failed';
        it.error = e.message || 'Upload failed.';
      }
    } finally {
      renderTray();
    }
  }

  function cancelUpload(it) {
    it.status = 'cancelled';
    if (it.xhr) it.xhr.abort();
    if (it.sid) post('/api/upload/cancel', { id: it.sid }).catch(() => {});
    renderTray();
  }

  let refreshTimer = null;
  function refreshSoon(dir) {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(() => {
      if (dir === S.path || dir.startsWith(S.path === '/' ? '/' : S.path + '/')) load(S.path, { keep: true });
    }, 500);
  }

  let trayFrame = 0;
  function scheduleTray() {
    if (trayFrame) return;
    trayFrame = requestAnimationFrame(() => { trayFrame = 0; renderTray(); });
  }

  function renderTray() {
    const items = Q.items.filter((i) => i.status !== 'cleared');
    const tray = $('tray');
    if (!items.length) { tray.hidden = true; renderBars(); return; }
    tray.hidden = false;
    const live = items.filter((i) => i.status !== 'cancelled');
    const total = live.reduce((n, i) => n + i.size, 0);
    const sent = live.reduce((n, i) => n + Math.min(i.sent, i.size), 0);
    const active = live.filter((i) => ['queued', 'uploading', 'retrying'].includes(i.status));
    const done = live.filter((i) => i.status === 'done' || i.status === 'skipped').length;
    const failed = live.filter((i) => i.status === 'failed').length;
    const now = performance.now();
    Q.samples.push({ t: now, b: sent });
    while (Q.samples.length > 2 && now - Q.samples[0].t > 4000) Q.samples.shift();
    const first = Q.samples[0];
    const speed = now - first.t > 500 ? ((sent - first.b) / (now - first.t)) * 1000 : 0;
    const pct = total ? Math.floor((sent / total) * 100) : 100;

    tray.classList.toggle('failed', !active.length && failed > 0);
    tray.classList.toggle('done', !active.length && !failed);
    if (active.length) {
      const retrying = active.some((i) => i.status === 'retrying');
      $('trayTitle').textContent = retrying ? 'Reconnecting to PC…' : 'Uploading to PC';
      const parts = [`${done} of ${live.length} done`];
      if (speed > 0) parts.push(fmtBytes(speed) + '/s');
      if (speed > 0) parts.push(fmtDuration((total - sent) / speed));
      $('traySub').textContent = parts.filter(Boolean).join(', ');
      $('trayPct').textContent = Math.min(pct, 99) + '%';
    } else if (failed) {
      $('trayTitle').textContent = plural(failed, 'upload') + ' failed';
      $('traySub').textContent = `${done} of ${live.length} done. Tap to retry.`;
      $('trayPct').textContent = '';
    } else {
      $('trayTitle').textContent = live.length ? plural(done, 'file') + ' uploaded' : 'Uploads cancelled';
      $('traySub').textContent = fmtBytes(total) + ' sent to ' + (S.info ? S.info.pcName : 'your PC');
      $('trayPct').innerHTML = live.length ? icon('check') : '';
    }
    $('trayBar').style.width = (active.length ? pct : live.length ? 100 : 0) + '%';

    if (Q.expanded) {
      $('trayList').innerHTML = items.map((i) => {
        const p = i.size ? Math.floor((Math.min(i.sent, i.size) / i.size) * 100) : 100;
        let status = '';
        let cls = '';
        let action = '';
        switch (i.status) {
          case 'queued': status = 'Waiting, ' + fmtBytes(i.size); action = `<button class="act" data-cancel="${i.id}" aria-label="Cancel">${icon('x')}</button>`; break;
          case 'uploading': status = `${p}%, ${fmtBytes(i.sent)} of ${fmtBytes(i.size)}`; action = `<button class="act" data-cancel="${i.id}" aria-label="Cancel">${icon('x')}</button>`; break;
          case 'retrying': status = `Reconnecting, ${p}% sent`; action = `<button class="act" data-cancel="${i.id}" aria-label="Cancel">${icon('x')}</button>`; break;
          case 'done': status = i.finalName && i.finalName !== i.name.split('/').pop() ? 'Saved as ' + i.finalName : 'Uploaded, ' + fmtBytes(i.size); cls = 'ok'; break;
          case 'skipped': status = 'Already on the PC'; cls = 'ok'; action = `<button class="act" data-force="${i.id}" aria-label="Upload a copy anyway">${icon('retry')}</button>`; break;
          case 'failed': status = i.error; cls = 'err'; action = `<button class="act" data-retry="${i.id}" aria-label="Retry">${icon('retry')}</button>`; break;
          case 'cancelled': status = 'Cancelled'; break;
        }
        const bar = ['uploading', 'retrying'].includes(i.status) ? `<span class="bar"><i style="width:${p}%"></i></span>` : '';
        return `<li><span class="n">${esc(i.name)}</span><span class="s ${cls}">${esc(status)}</span>${bar}${action}</li>`;
      }).join('');
    }
    renderBars();
  }

  $('trayHead').addEventListener('click', () => {
    Q.expanded = !Q.expanded;
    $('trayBody').hidden = !Q.expanded;
    $('trayHead').setAttribute('aria-expanded', String(Q.expanded));
    renderTray();
  });
  $('trayList').addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    const id = Number(b.dataset.cancel || b.dataset.retry || b.dataset.force);
    const it = Q.items.find((i) => i.id === id);
    if (!it) return;
    if (b.dataset.cancel) cancelUpload(it);
    else {
      it.force = !!b.dataset.force;
      it.status = 'queued';
      it.error = '';
      it.sent = 0;
      pump();
    }
  });
  $('trayClear').addEventListener('click', () => {
    for (const i of Q.items) if (['done', 'skipped', 'cancelled'].includes(i.status)) i.status = 'cleared';
    Q.items = Q.items.filter((i) => i.status !== 'cleared');
    if (!Q.items.length) { Q.expanded = false; $('trayBody').hidden = true; }
    renderTray();
  });
  window.addEventListener('beforeunload', (e) => {
    if (Q.items.some((i) => ['queued', 'uploading', 'retrying'].includes(i.status))) {
      e.preventDefault();
      e.returnValue = '';
    }
  });

  // Drag and drop (tablets and desktop browsers)
  let dragDepth = 0;
  const hasFiles = (e) => e.dataTransfer && [...e.dataTransfer.types].includes('Files');
  window.addEventListener('dragenter', (e) => { if (!hasFiles(e) || !S.info || !S.info.allowUpload) return; dragDepth++; $('drop').hidden = false; });
  window.addEventListener('dragleave', () => { dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) $('drop').hidden = true; });
  window.addEventListener('dragover', (e) => { if (hasFiles(e)) e.preventDefault(); });
  window.addEventListener('drop', (e) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    dragDepth = 0;
    $('drop').hidden = true;
    const files = [...e.dataTransfer.files].filter((f) => f.size > 0 || f.type);
    if (files.length) enqueue(files, S.path);
  });

  // ------------------------------------------------------------ viewer
  const V = { list: [], i: 0, dir: '/', open: false };

  function openViewer(entry, o = {}) {
    V.dir = S.path;
    V.list = S.shown.filter((e) => !e.dir && VIEWABLE.has(e.kind));
    V.i = V.list.findIndex((e) => e.name === entry.name);
    if (V.i < 0) { V.list = [entry]; V.i = 0; }
    V.open = true;
    $('viewer').hidden = false;
    overlayOpen(closeViewerNow, o);
    showItem();
  }

  function stopMedia() {
    for (const m of $('vStage').querySelectorAll('video, audio')) {
      m.pause();
      m.removeAttribute('src');
      m.load();
    }
  }

  function closeViewerNow() {
    stopMedia();
    $('vStage').innerHTML = '';
    $('viewer').hidden = true;
    V.open = false;
  }

  function fallbackCard(e, p, message) {
    const media = e.kind === 'video' || e.kind === 'audio';
    return `<div class="v-card"><div class="big">${icon(KIND_ICON[e.kind] || 'file')}</div>
      <h3>${esc(e.name)}</h3><p>${esc(message)}</p>
      <div class="btns">
        ${media && (IS_ANDROID || IS_IOS) ? `<a class="btn primary" href="${esc(appUrl(p, e.kind))}">${icon('external')}${IS_IOS ? 'Open in VLC' : 'Open in another app'}</a>` : ''}
        <a class="btn" href="${esc(fileUrl(p, '?dl=1'))}" download>${icon('download')}Download</a>
      </div></div>`;
  }

  async function showItem() {
    const e = V.list[V.i];
    if (!e) return;
    const p = joinPath(V.dir, e.name);
    const url = fileUrl(p);
    const stage = $('vStage');
    stopMedia();
    $('vName').textContent = e.name;
    $('vCount').textContent = V.list.length > 1 ? `${V.i + 1} of ${V.list.length}` : fmtBytes(e.size);
    $('vPrev').hidden = V.i === 0;
    $('vNext').hidden = V.i >= V.list.length - 1;

    const media = e.kind === 'video' || e.kind === 'audio';
    const info = S.info || {};
    $('vBar').innerHTML = `
      <a class="btn" href="${esc(fileUrl(p, '?dl=1'))}" download>${icon('download')}Download</a>
      ${media && (IS_ANDROID || IS_IOS) ? `<a class="btn" href="${esc(appUrl(p, e.kind))}">${icon('external')}${IS_IOS ? 'VLC' : 'Open in app'}</a>` : ''}
      ${!media && e.kind === 'pdf' ? `<a class="btn" href="${esc(url)}" target="_blank" rel="noopener">${icon('external')}Open</a>` : ''}
      ${info.allowModify ? `<button class="btn danger" type="button" id="vDelete">${icon('trash')}Delete</button>` : ''}`;
    const del = $('vDelete');
    if (del) del.addEventListener('click', async () => {
      const ok = await deleteEntries([e.name]);
      if (!ok) return;
      V.list.splice(V.i, 1);
      if (!V.list.length) return overlayClose();
      V.i = Math.min(V.i, V.list.length - 1);
      showItem();
    });

    if (e.kind === 'image' || e.kind === 'rawimage') {
      stage.innerHTML = '<div class="spinner"></div>';
      const img = new Image();
      img.alt = e.name;
      img.decoding = 'async';
      img.onload = () => { if (V.list[V.i] === e) { stage.innerHTML = ''; stage.appendChild(img); } };
      img.onerror = () => {
        if (V.list[V.i] === e) stage.innerHTML = fallbackCard(e, p, 'Your phone’s browser can’t show this image format. Download it to open it in your gallery app.');
      };
      img.src = url;
      for (const n of [V.list[V.i + 1], V.list[V.i - 1]]) {
        if (n && n.kind === 'image') { const pre = new Image(); pre.src = fileUrl(joinPath(V.dir, n.name)); }
      }
    } else if (e.kind === 'video') {
      stage.innerHTML = `<video controls playsinline autoplay preload="metadata"></video>`;
      const v = stage.querySelector('video');
      v.addEventListener('error', () => {
        if (V.list[V.i] === e) stage.innerHTML = fallbackCard(e, p, 'Your phone’s browser can’t play this video format. Open it in VLC or another player, or download it.');
      });
      v.src = url;
    } else if (e.kind === 'audio') {
      stage.innerHTML = `<div class="v-card"><div class="big">${icon('audio')}</div><h3>${esc(e.name)}</h3><p>${esc(fmtBytes(e.size))}</p><audio controls autoplay preload="metadata"></audio></div>`;
      const a = stage.querySelector('audio');
      a.addEventListener('ended', () => {
        const nextIdx = V.list.findIndex((x, j) => j > V.i && x.kind === 'audio');
        if (nextIdx > 0) { V.i = nextIdx; showItem(); }
      });
      a.addEventListener('error', () => {
        if (V.list[V.i] === e) stage.innerHTML = fallbackCard(e, p, 'Your phone’s browser can’t play this audio format.');
      });
      a.src = url;
    } else if (e.kind === 'text') {
      stage.innerHTML = '<div class="spinner"></div>';
      try {
        const limit = 512 * 1024;
        const res = await fetch(url, { headers: { Range: `bytes=0-${limit - 1}` }, credentials: 'same-origin' });
        const text = await res.text();
        if (V.list[V.i] !== e) return;
        const pre = document.createElement('pre');
        pre.textContent = text + (e.size > limit ? '\n\n… Showing the first 512 KB. Download the file to see all of it.' : '');
        stage.innerHTML = '';
        stage.appendChild(pre);
      } catch {
        if (V.list[V.i] === e) stage.innerHTML = fallbackCard(e, p, 'Couldn’t load this file.');
      }
    } else if (e.kind === 'pdf') {
      if (matchMedia('(pointer: fine)').matches) {
        stage.innerHTML = `<iframe src="${esc(url)}" title="${esc(e.name)}"></iframe>`;
      } else {
        stage.innerHTML = `<div class="v-card"><div class="big">${icon('pdf')}</div><h3>${esc(e.name)}</h3><p>${esc(fmtBytes(e.size))}</p>
          <div class="btns"><a class="btn primary" href="${esc(url)}" target="_blank" rel="noopener">${icon('external')}Open PDF</a>
          <a class="btn" href="${esc(fileUrl(p, '?dl=1'))}" download>${icon('download')}Download</a></div></div>`;
      }
    }
  }

  function step(d) {
    const n = V.i + d;
    if (n < 0 || n >= V.list.length) return;
    V.i = n;
    showItem();
  }
  $('vClose').addEventListener('click', overlayClose);
  $('vPrev').addEventListener('click', () => step(-1));
  $('vNext').addEventListener('click', () => step(1));
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && stack.length) { overlayClose(); return; }
    if (!V.open || stack[stack.length - 1] !== closeViewerNow) return;
    if (e.key === 'ArrowLeft') step(-1);
    else if (e.key === 'ArrowRight') step(1);
  });
  let touch = null;
  $('vStage').addEventListener('touchstart', (e) => {
    if (e.touches.length !== 1) { touch = null; return; }
    touch = { x: e.touches[0].clientX, y: e.touches[0].clientY, t: Date.now() };
  }, { passive: true });
  $('vStage').addEventListener('touchend', (e) => {
    if (!touch) return;
    const cur = V.list[V.i];
    const zoomed = window.visualViewport && window.visualViewport.scale > 1.02;
    const dx = e.changedTouches[0].clientX - touch.x;
    const dy = e.changedTouches[0].clientY - touch.y;
    const quick = Date.now() - touch.t < 600;
    touch = null;
    if (!cur || zoomed || !quick || (cur.kind !== 'image' && cur.kind !== 'rawimage')) return;
    if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) step(dx < 0 ? 1 : -1);
  }, { passive: true });

  // ------------------------------------------------------------ boot + heartbeat
  async function refreshInfo() {
    const before = S.info;
    S.info = await get('/api/info');
    if (before && before.rootId !== S.info.rootId && S.loaded) {
      toast('Your PC is now sharing a different folder.');
      go('/');
    }
    if (!S.info.hasRoot) showGate('noroot');
    renderBars();
  }

  async function boot() {
    if (location.hash === '#unpaired') {
      history.replaceState(null, '', location.pathname);
      showGate('unpaired');
      return;
    }
    try {
      await refreshInfo();
    } catch (e) {
      if (e.status === 0) showGate('offline');
      return;
    }
    if (!S.info.hasRoot) return;
    hideGate();
    await load(fromHash());
  }

  setInterval(() => {
    if (document.visibilityState !== 'visible' || !S.info) return;
    refreshInfo().catch(() => {});
  }, 25000);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && S.loaded) {
      refreshInfo().then(() => load(S.path, { keep: true })).catch(() => {});
    }
  });

  boot();
})();
