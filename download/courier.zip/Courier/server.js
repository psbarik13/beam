#!/usr/bin/env node
'use strict';
/*
 * Courier: share a PC folder with your phone over Wi-Fi.
 *   node server.js [--folder "D:\Share"] [--port 8765] [--no-open]
 * No npm install needed. Node.js 16 or newer.
 */
const http = require('http');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { Transform } = require('stream');
const { pipeline } = require('stream').promises;
const qr = require('./lib/qr');
const { writeZip } = require('./lib/zip');
const mime = require('./lib/mime');

const VERSION = '1.0.0';
const APP_DIR = __dirname;
const PUBLIC_DIR = path.join(APP_DIR, 'public');
const CONFIG_FILE = path.join(APP_DIR, 'courier.config.json');
const TMP_DIR_NAME = '.courier-tmp';
const IS_WIN = process.platform === 'win32';
const IS_MAC = process.platform === 'darwin';
const CHUNK_SIZE = 8 * 1024 * 1024;
const MAX_CHUNK = 64 * 1024 * 1024;
const HIDDEN_NAMES = new Set(['desktop.ini', 'thumbs.db', '$recycle.bin', 'system volume information', '.ds_store']);

// ---------------------------------------------------------------- config

const DEFAULTS = { port: 8765, root: null, recent: [], allowUpload: true, allowModify: true, token: null, ip: null };
let config = loadConfig();

function loadConfig() {
  try {
    const raw = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
    return { ...DEFAULTS, ...raw, recent: Array.isArray(raw.recent) ? raw.recent : [] };
  } catch {
    return { ...DEFAULTS };
  }
}

function saveConfig() {
  try {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
  } catch (e) {
    log(`Could not save settings to ${CONFIG_FILE}: ${e.message}`);
  }
}

function newToken() {
  return crypto.randomBytes(16).toString('base64url');
}

if (!config.token) {
  config.token = newToken();
  saveConfig();
}

// ---------------------------------------------------------------- runtime state

const runtime = {
  port: null,
  devices: new Map(),
  activity: [],
  uploads: new Map(),
  sse: new Set(),
  plays: new Map(),
  rootExists: false,
  seq: 0,
};

function log(msg) {
  const t = new Date().toLocaleTimeString();
  console.log(`  [${t}] ${msg}`);
}

class HttpError extends Error {
  constructor(status, message, extra) {
    super(message);
    this.status = status;
    this.extra = extra;
  }
}
function fail(status, message, extra) {
  throw new HttpError(status, message, extra);
}

// ---------------------------------------------------------------- helpers

function sendJson(res, status, obj, headers = {}) {
  if (res.headersSent || res.destroyed) return;
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
    ...headers,
  });
  res.end(body);
}

function sendText(res, status, text, type = 'text/plain; charset=utf-8', headers = {}) {
  if (res.headersSent || res.destroyed) return;
  res.writeHead(status, { 'Content-Type': type, 'Content-Length': Buffer.byteLength(text), ...headers });
  res.end(text);
}

async function readBody(req, limit = 1024 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit) fail(413, 'Request is too large.');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString('utf8');
}

async function readJson(req) {
  const text = await readBody(req);
  if (!text) return {};
  try {
    return JSON.parse(text);
  } catch {
    fail(400, 'Malformed request.');
  }
}

async function mapLimit(items, limit, fn) {
  const out = new Array(items.length);
  let i = 0;
  const worker = async () => {
    while (i < items.length) {
      const idx = i++;
      out[idx] = await fn(items[idx], idx);
    }
  };
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return out;
}

function withTimeout(promise, ms, fallback) {
  return Promise.race([promise, new Promise((r) => setTimeout(() => r(fallback), ms))]);
}

function formatBytes(n) {
  if (n == null) return '';
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return `${n < 10 && i ? n.toFixed(1) : Math.round(n)} ${u[i]}`;
}

function friendlyFsError(e) {
  switch (e && e.code) {
    case 'ENOENT': return 'That file or folder no longer exists on the PC.';
    case 'EACCES':
    case 'EPERM': return 'The PC refused access. The file may be open in another program, read-only, or protected.';
    case 'EBUSY': return 'The file is in use by another program on the PC.';
    case 'ENOSPC': return 'The PC has run out of disk space.';
    case 'ENOTDIR': return 'That path is a file, not a folder.';
    case 'EISDIR': return 'That path is a folder, not a file.';
    case 'ENAMETOOLONG': return 'That name is too long for the PC.';
    case 'EEXIST': return 'Something with that name already exists.';
    default: return `The PC reported an error: ${e && e.message ? e.message : e}`;
  }
}

// ---------------------------------------------------------------- network

function lanAddresses() {
  const out = [];
  for (const [name, list] of Object.entries(os.networkInterfaces())) {
    for (const a of list || []) {
      if (a.family !== 'IPv4' && a.family !== 4) continue;
      if (a.internal || a.address.startsWith('169.254.')) continue;
      out.push({ ip: a.address, name, score: scoreInterface(name, a.address) });
    }
  }
  return out.sort((x, y) => y.score - x.score);
}

function scoreInterface(name, ip) {
  const n = name.toLowerCase();
  let s = 0;
  if (/^192\.168\./.test(ip)) s += 30;
  else if (/^10\./.test(ip)) s += 20;
  else if (/^172\.(1[6-9]|2\d|3[01])\./.test(ip)) s += 10;
  if (/wi-?fi|wlan|wireless|^en0$/.test(n)) s += 15;
  if (/ethernet|^eth|^en\d/.test(n)) s += 8;
  if (/vethernet|virtual|vmware|vbox|hyper-v|wsl|docker|loopback|tailscale|zerotier|vpn|^tap|^tun|utun|hamachi|bluetooth|npcap|radmin|zscaler|zcc|^bridge|awdl|llw|anpi|ppp|ipsec|globalprotect|pangp|cisco|anyconnect|forti|wireguard/.test(n)) s -= 60;
  // 100.64.0.0/10 is used by Zscaler, Tailscale and carrier NAT, never by a home Wi-Fi.
  if (/^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./.test(ip)) s -= 60;
  return s;
}

function currentIp() {
  const addrs = lanAddresses();
  const chosen = addrs.find((a) => a.ip === config.ip);
  return (chosen || addrs[0] || {}).ip || null;
}

function pairUrl(ip = currentIp()) {
  return ip ? `http://${ip}:${runtime.port}/?k=${config.token}` : null;
}

function clientIp(req) {
  let a = req.socket.remoteAddress || '';
  if (a.startsWith('::ffff:')) a = a.slice(7);
  return a;
}

function isLoopback(req) {
  const ip = clientIp(req);
  if (ip !== '127.0.0.1' && ip !== '::1') return false;
  // Guard against DNS rebinding: a loopback request must also name localhost.
  const host = String(req.headers.host || '').toLowerCase().replace(/:\d+$/, '');
  return host === 'localhost' || host === '127.0.0.1' || host === '[::1]';
}

function cookieName() {
  return `courier_${runtime.port}`;
}

function parseCookies(req) {
  const out = {};
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function tokenOk(t) {
  if (!t) return false;
  const a = Buffer.from(String(t));
  const b = Buffer.from(config.token);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function isAuthed(req, url) {
  return (
    isLoopback(req) ||
    tokenOk(parseCookies(req)[cookieName()]) ||
    tokenOk(url.searchParams.get('k')) ||
    tokenOk(req.headers['x-courier-key'])
  );
}

function sameOrigin(req) {
  const o = req.headers.origin;
  if (!o) return true;
  try {
    return new URL(o).host === req.headers.host;
  } catch {
    return false;
  }
}

function deviceName(ua) {
  ua = String(ua || '');
  if (/iPhone/.test(ua)) return 'iPhone';
  if (/iPad/.test(ua)) return 'iPad';
  if (/Android/.test(ua)) {
    const m = /Android [\d.]+; (?:[a-z]{2}[-_][a-z]{2}; )?([^;)]+?)(?: Build[^;)]*)?\)/i.exec(ua);
    const model = m ? m[1].trim() : '';
    return model && model !== 'K' && model.length < 40 ? model : 'Android phone';
  }
  if (/Macintosh/.test(ua)) return 'Mac';
  if (/Windows/.test(ua)) return 'Windows PC';
  if (/Linux/.test(ua)) return 'Linux';
  return 'Device';
}

function touchDevice(req) {
  if (isLoopback(req)) return { name: 'This PC', ip: '127.0.0.1' };
  const ip = clientIp(req);
  const now = Date.now();
  let d = runtime.devices.get(ip);
  if (!d) {
    d = { ip, name: deviceName(req.headers['user-agent']), firstSeen: now, lastSeen: now };
    runtime.devices.set(ip, d);
    addActivity({ type: 'connect', device: d.name });
  } else {
    const gap = now - d.lastSeen;
    d.lastSeen = now;
    if (req.headers['user-agent']) d.name = deviceName(req.headers['user-agent']);
    if (gap > 90 * 1000) addActivity({ type: 'connect', device: d.name });
    else if (gap > 3000) broadcast();
  }
  return d;
}

// ---------------------------------------------------------------- activity + admin push

function addActivity(item) {
  item.id = ++runtime.seq;
  item.at = Date.now();
  runtime.activity.unshift(item);
  if (runtime.activity.length > 120) runtime.activity.length = 120;
  const who = item.device ? ` (${item.device})` : '';
  const size = item.size != null ? `, ${formatBytes(item.size)}` : '';
  const verbs = {
    connect: 'Connected', upload: 'Received', download: 'Sent', zip: 'Sent ZIP', play: 'Playing',
    mkdir: 'New folder', rename: 'Renamed', delete: 'Deleted', root: 'Sharing',
  };
  log(`${verbs[item.type] || item.type}${item.name ? ': ' + item.name : ''}${size}${who}`);
  broadcast();
}

let broadcastTimer = null;
function broadcast() {
  if (broadcastTimer) return;
  broadcastTimer = setTimeout(() => {
    broadcastTimer = null;
    if (!runtime.sse.size) return;
    const payload = `event: state\ndata: ${JSON.stringify(adminState())}\n\n`;
    for (const res of runtime.sse) res.write(payload);
  }, 120);
}

setInterval(() => {
  for (const res of runtime.sse) res.write(': ping\n\n');
  if (runtime.sse.size) broadcast();
}, 15000).unref();

async function checkRoot() {
  const root = config.root;
  const ok = root ? await withTimeout(fsp.stat(root).then((s) => s.isDirectory(), () => false), 3000, false) : false;
  if (root === config.root && ok !== runtime.rootExists) {
    runtime.rootExists = ok;
    broadcast();
  }
  return ok;
}
setInterval(() => { checkRoot().catch(() => {}); }, 15000).unref();

function rootName() {
  if (!config.root) return null;
  return path.basename(config.root) || config.root.replace(/[\\/]+$/, '');
}

function rootId() {
  return config.root ? crypto.createHash('sha1').update(config.root).digest('hex').slice(0, 10) : null;
}

function adminState() {
  const addrs = lanAddresses();
  const ip = currentIp();
  return {
    version: VERSION,
    platform: process.platform,
    pcName: os.hostname(),
    port: runtime.port,
    root: config.root,
    rootName: rootName(),
    rootExists: runtime.rootExists,
    recent: config.recent,
    allowUpload: config.allowUpload,
    allowModify: config.allowModify,
    addresses: addrs.map((a) => ({ ip: a.ip, name: a.name })),
    ip,
    pairUrl: pairUrl(ip),
    canPick: IS_WIN || IS_MAC || process.platform === 'linux',
    devices: [...runtime.devices.values()].sort((a, b) => b.lastSeen - a.lastSeen),
    activity: runtime.activity.slice(0, 60),
    uploading: runtime.uploads.size,
    now: Date.now(),
  };
}

// ---------------------------------------------------------------- paths

function requireRoot() {
  if (!config.root) fail(409, 'No folder is shared yet. Choose one on your PC.');
  return config.root;
}

function splitRel(rel) {
  const parts = String(rel || '').replace(/\\/g, '/').split('/').filter((p) => p && p !== '.');
  for (const p of parts) {
    if (p === '..' || p.includes('\0') || (IS_WIN && p.includes(':'))) fail(400, 'That path is not allowed.');
    if (p.toLowerCase() === TMP_DIR_NAME) fail(404, 'Not found.');
  }
  return parts;
}

function isInside(parent, child) {
  const r = path.relative(parent, child);
  return r === '' || (r !== '..' && !r.startsWith('..' + path.sep) && !path.isAbsolute(r));
}

function resolveRel(rel) {
  const root = requireRoot();
  const abs = path.resolve(root, ...splitRel(rel));
  if (!isInside(root, abs)) fail(403, 'That path is outside the shared folder.');
  return abs;
}

let realRootCache = { root: null, real: null };
async function realRoot() {
  if (realRootCache.root !== config.root) {
    realRootCache = { root: config.root, real: await fsp.realpath(config.root).catch(() => null) };
  }
  return realRootCache.real;
}

// Blocks symlinks/junctions that lead outside the shared folder.
async function assertReal(abs) {
  const rr = await realRoot();
  if (!rr) return;
  let real;
  try {
    real = await fsp.realpath(abs);
  } catch (e) {
    if (e.code === 'ENOENT') return;
    throw e;
  }
  if (!isInside(rr, real)) fail(403, 'That item links outside the shared folder.');
}

function oneName(name) {
  const n = String(name || '');
  if (!n || n.includes('/') || n.includes('\\')) fail(400, 'Invalid name.');
  splitRel(n);
  return n;
}

const RESERVED = /^(con|prn|aux|nul|com[0-9]|lpt[0-9])(\..*)?$/i;
function cleanName(name) {
  let n = String(name || '')
    .normalize('NFC')
    .replace(/[\x00-\x1f\x7f<>:"/\\|?*]/g, '_')
    .trim()
    .replace(/[. ]+$/, '');
  if (!n || n === '.' || n === '..') fail(400, 'Enter a valid name.');
  if (RESERVED.test(n)) n = '_' + n;
  if (n.toLowerCase() === TMP_DIR_NAME) fail(400, 'That name is reserved.');
  if (Buffer.byteLength(n) > 240) {
    const ext = path.extname(n).slice(0, 16);
    let base = n.slice(0, n.length - path.extname(n).length);
    while (Buffer.byteLength(base + ext) > 240) base = base.slice(0, -1);
    n = base + ext;
  }
  return n;
}

async function exists(p) {
  try {
    await fsp.lstat(p);
    return true;
  } catch (e) {
    if (e.code === 'ENOENT') return false;
    throw e;
  }
}

async function uniquePath(dir, name) {
  const ext = path.extname(name);
  const base = name.slice(0, name.length - ext.length);
  for (let i = 0; i < 10000; i++) {
    const candidate = path.join(dir, i === 0 ? name : `${base} (${i})${ext}`);
    if (!(await exists(candidate))) return candidate;
  }
  fail(409, 'Too many files with that name.');
}

async function renameWithRetry(from, to) {
  for (let attempt = 0; ; attempt++) {
    try {
      return await fsp.rename(from, to);
    } catch (e) {
      if (!['EBUSY', 'EPERM', 'EACCES'].includes(e.code) || attempt >= 6) throw e;
      await new Promise((r) => setTimeout(r, 150 * (attempt + 1)));
    }
  }
}

let lockChain = Promise.resolve();
function exclusive(fn) {
  const run = lockChain.then(fn, fn);
  lockChain = run.catch(() => {});
  return run;
}

function relOf(abs) {
  const r = path.relative(config.root, abs).split(path.sep).join('/');
  return r ? '/' + r : '/';
}

// ---------------------------------------------------------------- OS integration

// Runs a PowerShell script. Scripts report back with `CourierOut 'text'`, which writes a UTF-8
// file, so folder names in any language survive regardless of the console code page.
function runPowerShell(script, env = {}, timeoutMs = 120000) {
  return new Promise((resolve, reject) => {
    const outFile = path.join(os.tmpdir(), `courier-${process.pid}-${crypto.randomBytes(6).toString('hex')}.txt`);
    const prelude = "$ErrorActionPreference='Stop'\n$ProgressPreference='SilentlyContinue'\n" +
      'function CourierOut([string]$s) { [IO.File]::WriteAllText($env:COURIER_OUT, $s, (New-Object System.Text.UTF8Encoding $false)) }\n';
    const encoded = Buffer.from(prelude + script, 'utf16le').toString('base64');
    const ps = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-STA', '-EncodedCommand', encoded], {
      windowsHide: true,
      env: { ...process.env, ...env, COURIER_OUT: outFile },
      stdio: ['ignore', 'ignore', 'ignore'],
    });
    const timer = setTimeout(() => ps.kill(), timeoutMs);
    ps.on('error', (e) => { clearTimeout(timer); reject(e); });
    ps.on('close', (code) => {
      clearTimeout(timer);
      let text = '';
      try { text = fs.readFileSync(outFile, 'utf8').replace(/^\uFEFF/, '').trim(); } catch {}
      fs.unlink(outFile, () => {});
      if (text.startsWith('ERR:')) return reject(new Error(text.slice(4).trim()));
      if (!text && code !== 0) return reject(new Error(`PowerShell exited with code ${code}`));
      resolve(text);
    });
  });
}

function runCapture(cmd, args) {
  return new Promise((resolve, reject) => {
    const p = spawn(cmd, args, { windowsHide: true });
    const out = [];
    p.stdout.on('data', (d) => out.push(d));
    p.on('error', reject);
    p.on('close', (code) => resolve({ code, out: Buffer.concat(out).toString('utf8').trim() }));
  });
}

let pickerOpen = false;
async function pickFolderNative(initial) {
  if (pickerOpen) fail(409, 'The folder picker is already open on your PC. It may be behind this window.');
  pickerOpen = true;
  try {
    if (IS_WIN) {
      const script = `
try {
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.Application]::EnableVisualStyles()
  $owner = New-Object System.Windows.Forms.Form
  $owner.TopMost = $true
  $d = New-Object System.Windows.Forms.FolderBrowserDialog
  $d.Description = 'Choose the folder to share with your phone'
  $d.ShowNewFolderButton = $true
  if ($env:COURIER_INITIAL -and (Test-Path -LiteralPath $env:COURIER_INITIAL)) { $d.SelectedPath = $env:COURIER_INITIAL }
  $r = $d.ShowDialog($owner)
  $owner.Dispose()
  if ($r -eq [System.Windows.Forms.DialogResult]::OK) { CourierOut ('OK:' + $d.SelectedPath) } else { CourierOut 'CANCEL' }
} catch { CourierOut ('ERR:' + $_.Exception.Message); exit 2 }`;
      const out = await runPowerShell(script, { COURIER_INITIAL: initial || '' }, 30 * 60 * 1000);
      return out.startsWith('OK:') ? out.slice(3).trim() : null;
    }
    if (IS_MAC) {
      const r = await runCapture('osascript', ['-e', 'POSIX path of (choose folder with prompt "Choose the folder to share with your phone")']);
      return r.code === 0 && r.out ? r.out : null;
    }
    for (const [cmd, args] of [
      ['zenity', ['--file-selection', '--directory', '--title=Choose the folder to share with your phone']],
      ['kdialog', ['--getexistingdirectory', initial || os.homedir()]],
    ]) {
      try {
        const r = await runCapture(cmd, args);
        return r.code === 0 && r.out ? r.out : null;
      } catch (e) {
        if (e.code !== 'ENOENT') throw e;
      }
    }
    fail(501, 'No folder picker is available on this system. Browse or paste a path instead.');
  } finally {
    pickerOpen = false;
  }
}

async function moveToTrash(paths) {
  if (IS_WIN) {
    const script = `
try {
  Add-Type -AssemblyName Microsoft.VisualBasic
  foreach ($p in ($env:COURIER_PATHS -split [char]10)) {
    if (-not $p) { continue }
    if (Test-Path -LiteralPath $p -PathType Container) {
      [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory($p, 'OnlyErrorDialogs', 'SendToRecycleBin')
    } elseif (Test-Path -LiteralPath $p) {
      [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($p, 'OnlyErrorDialogs', 'SendToRecycleBin')
    }
  }
  CourierOut 'DONE'
} catch { CourierOut ('ERR:' + $_.Exception.Message); exit 2 }`;
    try {
      await runPowerShell(script, { COURIER_PATHS: paths.join('\n') });
    } catch (e) {
      fail(500, `Couldn't move it to the Recycle Bin: ${e.message}`);
    }
    return 'recycle';
  }
  if (IS_MAC) {
    // macOS 15+ ships /usr/bin/trash; older versions ask Finder (one-time Automation prompt).
    if (fs.existsSync('/usr/bin/trash')) {
      const r = await runCapture('/usr/bin/trash', paths);
      if (r.code !== 0) fail(500, "Couldn't move it to the Trash.");
      return 'trash';
    }
    const script = [
      'on run argv',
      '  repeat with p in argv',
      '    set f to (POSIX file (contents of p)) as alias',
      '    tell application "Finder" to delete f',
      '  end repeat',
      'end run',
    ].join('\n');
    const r = await runCapture('osascript', ['-e', script, ...paths]);
    if (r.code !== 0) {
      fail(500, "Couldn't move it to the Trash. On the Mac, allow Terminal to control Finder in System Settings, Privacy & Security, Automation.");
    }
    return 'trash';
  }
  for (const p of paths) await fsp.rm(p, { recursive: true, force: true });
  return 'permanent';
}

function openExternal(target) {
  try {
    let child;
    if (IS_WIN) {
      child = /^https?:/.test(target)
        ? spawn('rundll32.exe', ['url.dll,FileProtocolHandler', target], { detached: true, stdio: 'ignore', windowsHide: true })
        : spawn('explorer.exe', [target], { detached: true, stdio: 'ignore' });
    } else {
      child = spawn(IS_MAC ? 'open' : 'xdg-open', [target], { detached: true, stdio: 'ignore' });
    }
    child.on('error', () => {});
    child.unref();
  } catch {}
}

// ---------------------------------------------------------------- shared folder

async function setRoot(input) {
  if (!input || typeof input !== 'string') fail(400, 'Enter a folder path.');
  let abs = input.trim().replace(/^"(.*)"$/, '$1').trim();
  if (IS_WIN && /^[a-z]:$/i.test(abs)) abs += '\\';
  if (abs.startsWith('~')) abs = path.join(os.homedir(), abs.slice(1));
  abs = path.resolve(abs);
  let st;
  try {
    st = await fsp.stat(abs);
  } catch {
    fail(404, `Can't find the folder “${abs}”.`);
  }
  if (!st.isDirectory()) fail(400, 'That path is a file. Choose a folder.');
  const same = (a, b) => (IS_WIN ? a.toLowerCase() === b.toLowerCase() : a === b);
  config.root = abs;
  runtime.rootExists = true;
  config.recent = [abs, ...config.recent.filter((r) => !same(r, abs))].slice(0, 6);
  saveConfig();
  addActivity({ type: 'root', name: abs });
  cleanupTmp().catch(() => {});
  return abs;
}

async function tmpDir() {
  const dir = path.join(requireRoot(), TMP_DIR_NAME);
  if (!(await exists(dir))) {
    await fsp.mkdir(dir, { recursive: true });
    if (IS_WIN) spawn('attrib', ['+h', dir], { windowsHide: true, stdio: 'ignore' }).on('error', () => {});
  }
  return dir;
}

async function removeTmpIfEmpty() {
  if (!config.root || runtime.uploads.size) return;
  await fsp.rmdir(path.join(config.root, TMP_DIR_NAME)).catch(() => {});
}

async function cleanupTmp() {
  if (!config.root) return;
  const dir = path.join(config.root, TMP_DIR_NAME);
  let list;
  try { list = await fsp.readdir(dir); } catch { return; }
  const cutoff = Date.now() - 48 * 3600 * 1000;
  for (const f of list) {
    const p = path.join(dir, f);
    try {
      const st = await fsp.stat(p);
      if (st.mtimeMs < cutoff) await fsp.unlink(p);
    } catch {}
  }
  await removeTmpIfEmpty();
}

// ---------------------------------------------------------------- phone API

function requireUpload() {
  if (!config.allowUpload) fail(403, 'Uploading is turned off on the PC.');
}
function requireModify() {
  if (!config.allowModify) fail(403, 'Renaming and deleting are turned off on the PC.');
}

async function freeSpace() {
  if (!config.root || typeof fsp.statfs !== 'function') return null;
  try {
    const s = await fsp.statfs(config.root);
    return Number(s.bavail) * Number(s.bsize);
  } catch {
    return null;
  }
}

async function apiList(req, res, url) {
  const rel = url.searchParams.get('path') || '';
  const showHidden = url.searchParams.get('hidden') === '1';
  const abs = resolveRel(rel);
  await assertReal(abs);
  let dirents;
  try {
    dirents = await fsp.readdir(abs, { withFileTypes: true });
  } catch (e) {
    if (e.code === 'ENOENT') fail(404, 'This folder no longer exists on the PC.');
    if (e.code === 'ENOTDIR') fail(400, 'That is a file, not a folder.');
    throw e;
  }
  const entries = await mapLimit(dirents, 64, async (d) => {
    const name = d.name;
    if (name === TMP_DIR_NAME) return null;
    const hidden = name.startsWith('.') || HIDDEN_NAMES.has(name.toLowerCase());
    if (hidden && !showHidden) return null;
    try {
      const st = await fsp.stat(path.join(abs, name));
      const dir = st.isDirectory();
      if (!dir && !st.isFile()) return null;
      return {
        name,
        dir,
        size: dir ? null : st.size,
        mtime: Math.round(st.mtimeMs),
        kind: dir ? 'folder' : mime.kind(name, st.size),
        hidden,
      };
    } catch {
      return null;
    }
  });
  sendJson(res, 200, {
    path: '/' + splitRel(rel).join('/'),
    rootName: rootName(),
    rootId: rootId(),
    entries: entries.filter(Boolean),
    free: await freeSpace(),
  });
}

async function apiMkdir(req, res, device) {
  requireUpload();
  const body = await readJson(req);
  const dir = resolveRel(body.path);
  await assertReal(dir);
  const name = cleanName(body.name);
  await exclusive(async () => {
    try {
      await fsp.mkdir(path.join(dir, name));
    } catch (e) {
      if (e.code === 'EEXIST') fail(409, `“${name}” already exists here.`);
      if (e.code === 'ENOENT') fail(404, 'This folder no longer exists on the PC.');
      throw e;
    }
  });
  addActivity({ type: 'mkdir', name: relOf(path.join(dir, name)), device: device.name });
  sendJson(res, 200, { name });
}

async function apiRename(req, res, device) {
  requireModify();
  const body = await readJson(req);
  const dir = resolveRel(body.path);
  await assertReal(dir);
  const from = path.join(dir, oneName(body.from));
  const toName = cleanName(body.to);
  const to = path.join(dir, toName);
  await assertReal(from);
  await exclusive(async () => {
    if (!(await exists(from))) fail(404, 'That item no longer exists on the PC.');
    const caseOnly = IS_WIN || IS_MAC ? from.toLowerCase() === to.toLowerCase() : from === to;
    if (!caseOnly && (await exists(to))) fail(409, `“${toName}” already exists here.`);
    await renameWithRetry(from, to);
  });
  addActivity({ type: 'rename', name: `${body.from} → ${toName}`, device: device.name });
  sendJson(res, 200, { name: toName });
}

async function apiDelete(req, res, device) {
  requireModify();
  const body = await readJson(req);
  const dir = resolveRel(body.path);
  await assertReal(dir);
  const names = Array.isArray(body.names) ? body.names.map(oneName) : [];
  if (!names.length) fail(400, 'Nothing selected.');
  const targets = [];
  for (const n of names) {
    const p = path.join(dir, n);
    if (await exists(p)) targets.push(p);
  }
  const mode = targets.length ? await moveToTrash(targets) : 'none';
  addActivity({
    type: 'delete',
    name: names.length === 1 ? relOf(targets[0] || path.join(dir, names[0])) : `${names.length} items in ${relOf(dir)}`,
    device: device.name,
  });
  sendJson(res, 200, { deleted: targets.length, mode });
}

function uploadId(targetDir, fileName, size, mtime) {
  return crypto
    .createHash('sha256')
    .update([config.root, targetDir, fileName, size, mtime || 0].join('\n'))
    .digest('hex')
    .slice(0, 32);
}

async function apiUploadInit(req, res) {
  requireUpload();
  const body = await readJson(req);
  const size = Number(body.size);
  if (!Number.isSafeInteger(size) || size < 0) fail(400, 'Invalid file size.');
  const nameParts = String(body.name || '').replace(/\\/g, '/').split('/').filter(Boolean).map(cleanName);
  if (!nameParts.length) fail(400, 'Missing file name.');
  const fileName = nameParts.pop();
  const baseDir = resolveRel(body.path);
  await assertReal(baseDir);
  const targetDir = resolveRel([...splitRel(body.path), ...nameParts].join('/'));
  const mtime = Number.isFinite(Number(body.mtime)) && Number(body.mtime) > 0 ? Number(body.mtime) : null;

  // Same name and same size already there: treat as already transferred.
  try {
    const st = await fsp.stat(path.join(targetDir, fileName));
    if (st.isFile() && st.size === size && !body.force) {
      return sendJson(res, 200, { exists: true, name: fileName });
    }
  } catch {}

  const id = uploadId(targetDir, fileName, size, mtime);
  let s = runtime.uploads.get(id);
  if (!s) {
    const part = path.join(await tmpDir(), id + '.part');
    let received = 0;
    try {
      received = (await fsp.stat(part)).size;
    } catch {
      await fsp.writeFile(part, '');
    }
    if (received > size) {
      await fsp.truncate(part, 0);
      received = 0;
    }
    s = { id, part, targetDir, fileName, size, mtime, received, busy: false, touched: Date.now() };
    runtime.uploads.set(id, s);
  }
  s.touched = Date.now();
  sendJson(res, 200, { id, offset: s.received, chunkSize: CHUNK_SIZE });
}

function drainThen(req, fn) {
  req.resume();
  req.on('end', fn);
  req.on('error', () => {});
}

async function apiUploadChunk(req, res, url) {
  requireUpload();
  const s = runtime.uploads.get(url.searchParams.get('id') || '');
  if (!s) return drainThen(req, () => sendJson(res, 404, { error: 'Upload session expired.', code: 'expired' }));
  const offset = Number(url.searchParams.get('offset'));
  if (s.busy || offset !== s.received) {
    return drainThen(req, () => sendJson(res, 409, { error: 'Offset mismatch.', offset: s.received }));
  }
  s.busy = true;
  s.touched = Date.now();
  let count = 0;
  const limit = Math.min(s.size - offset, MAX_CHUNK);
  const guard = new Transform({
    transform(chunk, _enc, cb) {
      count += chunk.length;
      if (count > limit) cb(new HttpError(413, 'More data than expected.'));
      else cb(null, chunk);
    },
  });
  try {
    await pipeline(req, guard, fs.createWriteStream(s.part, { flags: 'a' }));
  } catch (e) {
    if (e instanceof HttpError) await fsp.truncate(s.part, offset).catch(() => {});
    s.received = await fsp.stat(s.part).then((st) => st.size, () => 0);
    s.busy = false;
    if (e instanceof HttpError) throw e;
    return; // client went away; partial data is kept for resume
  }
  s.received = (await fsp.stat(s.part)).size;
  s.busy = false;
  sendJson(res, 200, { offset: s.received });
}

async function apiUploadFinish(req, res, device) {
  requireUpload();
  const body = await readJson(req);
  const s = runtime.uploads.get(String(body.id || ''));
  if (!s) fail(404, 'Upload session expired.', { code: 'expired' });
  if (s.busy || s.received !== s.size) fail(409, 'Upload is not complete yet.', { offset: s.received });
  const dest = await exclusive(async () => {
    await fsp.mkdir(s.targetDir, { recursive: true });
    const target = await uniquePath(s.targetDir, s.fileName);
    try {
      await renameWithRetry(s.part, target);
    } catch (e) {
      if (e.code !== 'EXDEV') throw e;
      await fsp.copyFile(s.part, target);
      await fsp.unlink(s.part);
    }
    return target;
  });
  runtime.uploads.delete(s.id);
  if (s.mtime) await fsp.utimes(dest, new Date(), new Date(s.mtime)).catch(() => {});
  addActivity({ type: 'upload', name: relOf(dest), size: s.size, device: device.name });
  removeTmpIfEmpty();
  sendJson(res, 200, { name: path.basename(dest), path: relOf(path.dirname(dest)) });
}

async function apiUploadCancel(req, res) {
  const body = await readJson(req);
  const s = runtime.uploads.get(String(body.id || ''));
  if (s && !s.busy) {
    runtime.uploads.delete(s.id);
    await fsp.unlink(s.part).catch(() => {});
    removeTmpIfEmpty();
  }
  sendJson(res, 200, { ok: true });
}

setInterval(() => {
  const cutoff = Date.now() - 6 * 3600 * 1000;
  for (const [id, s] of runtime.uploads) if (!s.busy && s.touched < cutoff) runtime.uploads.delete(id);
}, 600000).unref();

function contentDisposition(name, download) {
  const ascii = name.replace(/[^\x20-\x7e]|["\\%]/g, '_');
  const encoded = encodeURIComponent(name).replace(/['()*]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());
  return `${download ? 'attachment' : 'inline'}; filename="${ascii}"; filename*=UTF-8''${encoded}`;
}

async function serveFile(req, res, abs, { download, device }) {
  let st;
  try {
    st = await fsp.stat(abs);
  } catch (e) {
    if (e.code === 'ENOENT') fail(404, 'That file no longer exists on the PC.');
    throw e;
  }
  if (!st.isFile()) fail(404, 'That is not a file.');
  const name = path.basename(abs);
  const type = mime.lookup(name, st.size);
  const etag = `"${st.size.toString(16)}-${Math.floor(st.mtimeMs).toString(16)}"`;
  const headers = {
    'Content-Type': /^text\/|json$|xml$/.test(type) ? `${type}; charset=utf-8` : type,
    'Accept-Ranges': 'bytes',
    'Last-Modified': st.mtime.toUTCString(),
    ETag: etag,
    'Cache-Control': 'private, no-cache',
    'Content-Disposition': contentDisposition(name, download),
  };
  // Never let an HTML/SVG file from the share run scripts on this origin.
  if (/html|xml|svg/.test(type)) headers['Content-Security-Policy'] = 'sandbox';

  if (!req.headers.range && req.headers['if-none-match'] === etag) {
    res.writeHead(304, headers);
    return res.end();
  }

  let start = 0;
  let end = st.size - 1;
  let status = 200;
  const range = req.headers.range;
  const ifRange = req.headers['if-range'];
  if (range && (!ifRange || ifRange === etag)) {
    const m = /^bytes=(\d*)-(\d*)$/.exec(range.trim());
    if (m && (m[1] !== '' || m[2] !== '')) {
      if (m[1] === '') {
        start = Math.max(0, st.size - Number(m[2]));
      } else {
        start = Number(m[1]);
        end = m[2] === '' ? st.size - 1 : Math.min(Number(m[2]), st.size - 1);
      }
      if (start > end || start >= st.size) {
        res.writeHead(416, { 'Content-Range': `bytes */${st.size}` });
        return res.end();
      }
      status = 206;
      headers['Content-Range'] = `bytes ${start}-${end}/${st.size}`;
    }
  }

  if (req.method === 'GET' && start === 0) {
    if (download) {
      addActivity({ type: 'download', name: relOf(abs), size: st.size, device: device.name });
    } else if (/^(video|audio)\//.test(type)) {
      const key = device.ip + '|' + abs;
      const last = runtime.plays.get(key) || 0;
      if (Date.now() - last > 10 * 60 * 1000) addActivity({ type: 'play', name: relOf(abs), device: device.name });
      runtime.plays.set(key, Date.now());
    }
  }

  headers['Content-Length'] = st.size === 0 ? 0 : end - start + 1;
  res.writeHead(status, headers);
  if (req.method === 'HEAD' || st.size === 0) return res.end();
  await pipeline(fs.createReadStream(abs, { start, end, highWaterMark: 1024 * 1024 }), res).catch(() => {});
}

async function collectZipEntries(baseDir, names) {
  const entries = [];
  const rr = await realRoot();
  const walk = async (abs, zipName) => {
    let lst;
    try { lst = await fsp.lstat(abs); } catch { return; }
    if (lst.isSymbolicLink()) {
      try {
        const real = await fsp.realpath(abs);
        if (rr && !isInside(rr, real)) return;
      } catch { return; }
    }
    let st;
    try { st = await fsp.stat(abs); } catch { return; }
    if (st.isDirectory()) {
      entries.push({ name: zipName + '/', dir: true, mtime: st.mtime });
      let list;
      try { list = await fsp.readdir(abs); } catch { return; }
      list.sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }));
      for (const n of list) {
        if (n === TMP_DIR_NAME || HIDDEN_NAMES.has(n.toLowerCase())) continue;
        await walk(path.join(abs, n), `${zipName}/${n}`);
      }
    } else if (st.isFile()) {
      entries.push({ name: zipName, abs, size: st.size, mtime: st.mtime, dir: false });
    }
  };
  for (const n of names) await walk(path.join(baseDir, n), n);
  return entries;
}

async function apiZip(req, res, url, device) {
  let rel = url.searchParams.get('path');
  let names = url.searchParams.getAll('names');
  if (req.method === 'POST') {
    const form = new URLSearchParams(await readBody(req, 4 * 1024 * 1024));
    rel = form.get('path');
    names = form.getAll('names');
  }
  const dir = resolveRel(rel);
  await assertReal(dir);
  names = names.map(oneName);
  if (!names.length) fail(400, 'Nothing selected.');
  const entries = await collectZipEntries(dir, names);
  if (!entries.length) fail(404, 'Nothing to download.');
  const total = entries.reduce((n, e) => n + (e.size || 0), 0);
  const base = names.length === 1 ? names[0] : (path.basename(dir) || rootName() || 'Courier');
  const zipName = `${base}.zip`;
  res.writeHead(200, {
    'Content-Type': 'application/zip',
    'Content-Disposition': contentDisposition(zipName, true),
    'Cache-Control': 'no-store',
  });
  addActivity({ type: 'zip', name: `${zipName} (${entries.filter((e) => !e.dir).length} files)`, size: total, device: device.name });
  try {
    await writeZip(res, entries);
    res.end();
  } catch {
    res.destroy();
  }
}

// ---------------------------------------------------------------- admin API

async function browseDirs(input) {
  if (!input) {
    const roots = [];
    if (IS_WIN) {
      const letters = 'CDEFGHIJKLMNOPQRSTUVWXYZAB'.split('');
      const found = await Promise.all(
        letters.map((L) => withTimeout(fsp.stat(`${L}:\\`).then(() => true, () => false), 1500, false)),
      );
      letters.forEach((L, i) => { if (found[i]) roots.push({ name: `${L}:`, path: `${L}:\\` }); });
      roots.sort((a, b) => a.name.localeCompare(b.name));
    } else {
      roots.push({ name: IS_MAC ? 'Computer' : '/', path: '/' });
      if (IS_MAC) {
        try {
          for (const v of await fsp.readdir('/Volumes')) {
            if (!v.startsWith('.')) roots.push({ name: v, path: path.join('/Volumes', v) });
          }
        } catch {}
      }
    }
    const home = os.homedir();
    const places = [{ name: 'Home', path: home }];
    for (const n of ['Desktop', 'Downloads', 'Documents', 'Pictures', 'Videos', 'Movies', 'Music']) {
      const p = path.join(home, n);
      if (fs.existsSync(p)) places.push({ name: n, path: p });
    }
    return { path: '', parent: null, dirs: roots, places };
  }
  let abs = String(input).trim().replace(/^"(.*)"$/, '$1');
  if (IS_WIN && /^[a-z]:$/i.test(abs)) abs += '\\';
  abs = path.resolve(abs);
  const list = await fsp.readdir(abs, { withFileTypes: true });
  const dirs = [];
  for (const d of list) {
    if (d.name.startsWith('.') || d.name.startsWith('$') || HIDDEN_NAMES.has(d.name.toLowerCase())) continue;
    let isDir = d.isDirectory();
    if (!isDir && d.isSymbolicLink()) {
      isDir = await fsp.stat(path.join(abs, d.name)).then((s) => s.isDirectory(), () => false);
    }
    if (isDir) dirs.push({ name: d.name, path: path.join(abs, d.name) });
  }
  dirs.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' }));
  const parent = path.dirname(abs);
  return { path: abs, parent: parent === abs ? '' : parent, dirs };
}

async function handleAdmin(req, res, url) {
  const p = url.pathname;
  if (!isLoopback(req)) {
    return sendText(res, 403, 'The Courier control page only opens on the PC that runs it: http://localhost:' + runtime.port);
  }
  if (req.method === 'POST' && !sameOrigin(req)) fail(403, 'Blocked a cross-site request.');

  if (p === '/admin' || p === '/admin/') return serveStatic(res, 'admin.html');

  if (p === '/admin/events') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
    res.write(`retry: 2000\nevent: state\ndata: ${JSON.stringify(adminState())}\n\n`);
    runtime.sse.add(res);
    req.on('close', () => runtime.sse.delete(res));
    return;
  }

  if (p === '/admin/api/state') return sendJson(res, 200, adminState());

  if (p === '/admin/qr.svg') {
    const target = pairUrl(url.searchParams.get('ip') || currentIp());
    if (!target) return sendText(res, 404, 'No network');
    return sendText(res, 200, qr.toSvg(target, { dark: '#0f2740' }), 'image/svg+xml', { 'Cache-Control': 'no-store' });
  }

  if (req.method !== 'POST') fail(405, 'Method not allowed.');

  if (p === '/admin/api/root') {
    const body = await readJson(req);
    await setRoot(body.path);
    return sendJson(res, 200, adminState());
  }
  if (p === '/admin/api/pick') {
    const picked = await pickFolderNative(config.root);
    if (!picked) return sendJson(res, 200, { cancelled: true, state: adminState() });
    await setRoot(picked);
    return sendJson(res, 200, { cancelled: false, state: adminState() });
  }
  if (p === '/admin/api/browse') {
    const body = await readJson(req);
    try {
      return sendJson(res, 200, await browseDirs(body.path));
    } catch (e) {
      fail(e.code === 'ENOENT' ? 404 : 400, friendlyFsError(e));
    }
  }
  if (p === '/admin/api/settings') {
    const body = await readJson(req);
    if (typeof body.allowUpload === 'boolean') config.allowUpload = body.allowUpload;
    if (typeof body.allowModify === 'boolean') config.allowModify = body.allowModify;
    if (typeof body.ip === 'string') config.ip = body.ip;
    saveConfig();
    broadcast();
    return sendJson(res, 200, adminState());
  }
  if (p === '/admin/api/rotate') {
    config.token = newToken();
    saveConfig();
    runtime.devices.clear();
    log('Made a new phone link. Phones paired earlier must scan the new QR code.');
    broadcast();
    return sendJson(res, 200, adminState());
  }
  if (p === '/admin/api/open') {
    if (config.root) openExternal(config.root);
    return sendJson(res, 200, { ok: true });
  }
  fail(404, 'Not found.');
}

// ---------------------------------------------------------------- static

const STATIC_TYPES = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.webmanifest': 'application/manifest+json' };
const PAGE_CSP = "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; frame-src 'self'; frame-ancestors 'none'";

async function serveStatic(res, file) {
  const abs = path.join(PUBLIC_DIR, file);
  let data;
  try {
    data = await fsp.readFile(abs);
  } catch {
    return sendText(res, 404, 'Not found');
  }
  res.writeHead(200, {
    'Content-Type': STATIC_TYPES[path.extname(file)] || 'application/octet-stream',
    'Content-Length': data.length,
    'Cache-Control': 'no-cache',
    'Content-Security-Policy': PAGE_CSP,
    'X-Frame-Options': 'DENY',
  });
  res.end(data);
}

// ---------------------------------------------------------------- router

async function route(req, res, url) {
  const p = url.pathname;

  if (p === '/admin' || p.startsWith('/admin/')) return handleAdmin(req, res, url);

  if (['/app.css', '/app.js', '/icon.svg', '/manifest.webmanifest'].includes(p)) return serveStatic(res, p.slice(1));
  if (p === '/favicon.ico') return serveStatic(res, 'icon.svg');

  if (p === '/' || p === '/browse') {
    const k = url.searchParams.get('k');
    if (k) {
      if (tokenOk(k)) {
        res.writeHead(302, {
          Location: '/',
          'Set-Cookie': `${cookieName()}=${encodeURIComponent(k)}; Path=/; Max-Age=2592000; HttpOnly; SameSite=Lax`,
          'Cache-Control': 'no-store',
        });
        return res.end();
      }
      res.writeHead(302, { Location: '/#unpaired', 'Cache-Control': 'no-store' });
      return res.end();
    }
    if (p === '/' && isLoopback(req)) {
      res.writeHead(302, { Location: '/admin' });
      return res.end();
    }
    return serveStatic(res, 'app.html');
  }

  const isApi = p.startsWith('/api/');
  const isFile = p.startsWith('/f/');
  if (!isApi && !isFile) fail(404, 'Not found.');
  if (!isAuthed(req, url)) fail(401, 'This phone is not connected. Scan the QR code on your PC again.', { code: 'unpaired' });
  if (req.method !== 'GET' && req.method !== 'HEAD' && !sameOrigin(req)) fail(403, 'Blocked a cross-site request.');
  const device = touchDevice(req);

  if (isFile) {
    if (req.method !== 'GET' && req.method !== 'HEAD') fail(405, 'Method not allowed.');
    let rel;
    try {
      rel = p.slice(3).split('/').map(decodeURIComponent).join('/');
    } catch {
      fail(400, 'Malformed path.');
    }
    const abs = resolveRel(rel);
    await assertReal(abs);
    return serveFile(req, res, abs, { download: url.searchParams.get('dl') === '1', device });
  }

  const routes = {
    'GET /api/info': async () => sendJson(res, 200, {
      version: VERSION,
      pcName: os.hostname(),
      hasRoot: !!config.root,
      rootName: rootName(),
      rootId: rootId(),
      allowUpload: config.allowUpload,
      allowModify: config.allowModify,
      chunkSize: CHUNK_SIZE,
      token: config.token,
      trash: IS_WIN ? 'recycle' : IS_MAC ? 'trash' : 'permanent',
    }),
    'GET /api/list': () => apiList(req, res, url),
    'POST /api/mkdir': () => apiMkdir(req, res, device),
    'POST /api/rename': () => apiRename(req, res, device),
    'POST /api/delete': () => apiDelete(req, res, device),
    'POST /api/upload/init': () => apiUploadInit(req, res),
    'PUT /api/upload/chunk': () => apiUploadChunk(req, res, url),
    'POST /api/upload/finish': () => apiUploadFinish(req, res, device),
    'POST /api/upload/cancel': () => apiUploadCancel(req, res),
    'GET /api/zip': () => apiZip(req, res, url, device),
    'POST /api/zip': () => apiZip(req, res, url, device),
  };
  const handler = routes[`${req.method} ${p}`];
  if (!handler) fail(404, 'Not found.');
  return handler();
}

async function onRequest(req, res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  let url;
  try {
    url = new URL(req.url, 'http://localhost');
  } catch {
    return sendText(res, 400, 'Bad request');
  }
  try {
    await route(req, res, url);
  } catch (e) {
    const status = e.status || ({ ENOENT: 404, EACCES: 403, EPERM: 403, EBUSY: 423, ENOSPC: 507, EEXIST: 409 }[e.code] || 500);
    if (!e.status && status === 500) console.error(e);
    if (res.headersSent) return res.destroy();
    req.resume();
    sendJson(res, status, { error: e.status ? e.message : friendlyFsError(e), ...(e.extra || {}) });
  }
}

// ---------------------------------------------------------------- startup

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--port' || a === '-p') out.port = Number(argv[++i]);
    else if (a === '--folder' || a === '--root' || a === '-f') out.root = argv[++i];
    else if (a === '--no-open') out.noOpen = true;
    else if (a === '--help' || a === '-h') out.help = true;
    else if (!a.startsWith('-') && !out.root) out.root = a;
  }
  return out;
}

function listen(server, port) {
  return new Promise((resolve, reject) => {
    const attempt = (p, host, triesLeft) => {
      const onError = (e) => {
        server.off('listening', onListening);
        if (e.code === 'EAFNOSUPPORT' || e.code === 'EADDRNOTAVAIL') return attempt(p, '0.0.0.0', triesLeft);
        if (e.code === 'EADDRINUSE' && triesLeft > 0) return attempt(p + 1, host, triesLeft - 1);
        reject(e);
      };
      const onListening = () => {
        server.off('error', onError);
        resolve(server.address().port);
      };
      server.once('error', onError);
      server.once('listening', onListening);
      server.listen(p, host);
    };
    attempt(port, '::', 20);
  });
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    console.log('Usage: node server.js [--folder <path>] [--port <number>] [--no-open]');
    return;
  }
  const major = Number(process.versions.node.split('.')[0]);
  if (major < 16) {
    console.error(`Courier needs Node.js 16 or newer. You have ${process.versions.node}.`);
    process.exit(1);
  }
  process.title = 'Courier';
  if (args.root) {
    try {
      await setRoot(args.root);
    } catch (e) {
      console.error(`  ${e.message}`);
    }
  }
  if (config.root && !(await checkRoot())) {
    console.log(`  The last shared folder is missing: ${config.root}`);
  }

  const server = http.createServer(onRequest);
  server.requestTimeout = 0;
  server.headersTimeout = 60000;
  server.keepAliveTimeout = 10000;
  runtime.port = await listen(server, Number(args.port) || config.port || 8765);
  cleanupTmp().catch(() => {});

  const local = `http://localhost:${runtime.port}/admin`;
  const phone = pairUrl();
  console.log('');
  console.log('  Courier is running.');
  console.log('');
  console.log(`  Control page (this PC):  ${local}`);
  console.log(`  Shared folder:           ${config.root || 'none yet, choose one on the control page'}`);
  if (phone) console.log(`  Phone link:              ${phone}`);
  else console.log('  No Wi-Fi or Ethernet network found. Connect this PC to the same network as your phone.');
  if (phone && config.root) {
    console.log('');
    console.log(qr.toTerminal(phone).split('\n').map((l) => '  ' + l).join('\n'));
  }
  console.log('');
  console.log('  Keep this window open while you transfer. Press Ctrl+C to stop.');
  console.log('');
  if (!args.noOpen) openExternal(local);

  const shutdown = () => {
    console.log('\n  Courier stopped.');
    process.exit(0);
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

process.on('unhandledRejection', (e) => console.error('  Unexpected error:', e));
process.on('uncaughtException', (e) => {
  if (e && (e.code === 'EPIPE' || e.code === 'ECONNRESET')) return;
  console.error('  Unexpected error:', e);
});

main().catch((e) => {
  console.error(`  Courier could not start: ${e.message}`);
  process.exit(1);
});
