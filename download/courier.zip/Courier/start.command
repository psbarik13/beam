#!/bin/bash
# Double-click to start Courier on macOS.
cd "$(dirname "$0")" || exit 1
# Finder-launched scripts don't load your shell profile, so add the usual Node locations.
export PATH="/opt/homebrew/bin:/usr/local/bin:$HOME/.volta/bin:$PATH"
[ -s "$HOME/.nvm/nvm.sh" ] && . "$HOME/.nvm/nvm.sh" >/dev/null 2>&1
if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "  Node.js is not installed. Get it from https://nodejs.org (LTS), then run this again."
  echo ""
  read -n 1 -s -r -p "  Press any key to close."
  exit 1
fi
printf '\033]0;Courier\007'
node server.js "$@"
